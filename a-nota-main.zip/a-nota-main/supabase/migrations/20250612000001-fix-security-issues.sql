
-- Fix security issues in Supabase database

-- 1. Remove any SECURITY DEFINER views if they exist
DROP VIEW IF EXISTS public.invoices_summary CASCADE;

-- 2. Recreate invoices_summary as a regular view without SECURITY DEFINER
CREATE VIEW public.invoices_summary AS
SELECT 
  id,
  request_number,
  creditor_name,
  creditor_cnpj,
  invoice_number,
  competence,
  value,
  status,
  species,
  observation,
  owner,
  created_at,
  updated_at
FROM public.invoices;

-- 3. Update existing functions to remove unnecessary SECURITY DEFINER where not needed
-- Keep SECURITY DEFINER only for functions that truly need elevated privileges

-- Update get_user_profile function to be more secure
CREATE OR REPLACE FUNCTION public.get_user_profile(user_id uuid)
RETURNS TABLE(
  id uuid,
  email text,
  nome text,
  telefone text,
  cargo text,
  foto text,
  is_active boolean
)
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT 
    up.id,
    up.email,
    up.nome,
    up.telefone,
    up.cargo,
    up.foto,
    up.is_active
  FROM public.user_profiles up
  WHERE up.id = user_id
    AND up.id = auth.uid(); -- Additional security check
$$;

-- Update update_user_profile function to be more secure
CREATE OR REPLACE FUNCTION public.update_user_profile(
  user_id uuid,
  profile_data jsonb
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Only allow users to update their own profile
  IF user_id != auth.uid() THEN
    RAISE EXCEPTION 'Access denied: You can only update your own profile';
  END IF;

  UPDATE public.user_profiles
  SET 
    nome = COALESCE(profile_data->>'nome', nome),
    telefone = COALESCE(profile_data->>'telefone', telefone),
    cargo = COALESCE(profile_data->>'cargo', cargo),
    foto = COALESCE(profile_data->>'foto', foto),
    is_active = COALESCE((profile_data->>'is_active')::boolean, is_active),
    updated_at = NOW()
  WHERE id = user_id;
END;
$$;

-- 4. Add proper RLS policies to user_profiles table
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view own profile" ON public.user_profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON public.user_profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.user_profiles;

-- Create secure RLS policies
CREATE POLICY "Users can view own profile" ON public.user_profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.user_profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.user_profiles
  FOR UPDATE USING (auth.uid() = id);

-- 5. Ensure invoices table has proper RLS
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

-- Add basic policies for invoices (adjust according to your business logic)
CREATE POLICY "Authenticated users can view invoices" ON public.invoices
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert invoices" ON public.invoices
  FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update invoices" ON public.invoices
  FOR UPDATE TO authenticated
  USING (true);

-- 6. Ensure certificates table has proper RLS
ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view certificates" ON public.certificates
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert certificates" ON public.certificates
  FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update certificates" ON public.certificates
  FOR UPDATE TO authenticated
  USING (true);

-- 7. Ensure credores table has proper RLS
ALTER TABLE public.credores ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view credores" ON public.credores
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert credores" ON public.credores
  FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update credores" ON public.credores
  FOR UPDATE TO authenticated
  USING (true);

-- 8. Ensure justifications table has proper RLS
ALTER TABLE public.justifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view justifications" ON public.justifications
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert justifications" ON public.justifications
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- 9. Ensure projects table has proper RLS
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view projects" ON public.projects
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert projects" ON public.projects
  FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update projects" ON public.projects
  FOR UPDATE TO authenticated
  USING (true);
