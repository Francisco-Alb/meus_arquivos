
-- Remover a função problemática que referencia 'full_name'
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Remover trigger conflitante se existir
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Assegurar que a função correta existe
CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, nome, cargo, telefone)
  VALUES (
    NEW.id, 
    NEW.email, 
    COALESCE(NEW.raw_user_meta_data->>'nome', NEW.email), 
    COALESCE(NEW.raw_user_meta_data->>'cargo', 'gerente_prestacao_contas'),
    COALESCE(NEW.raw_user_meta_data->>'telefone', NULL)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recriar o trigger correto
DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_profile
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_profile();
