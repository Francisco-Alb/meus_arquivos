
-- Remove a view existente com SECURITY DEFINER
DROP VIEW IF EXISTS public.invoices_summary CASCADE;

-- Recria a view sem SECURITY DEFINER (padrão é SECURITY INVOKER)
CREATE VIEW public.invoices_summary AS
SELECT 
  id,
  request_number,
  creditor_name,
  creditor_cnpj,
  invoice_number,
  competence,
  value,
  status,
  species,
  observation,
  owner,
  created_at,
  updated_at
FROM public.invoices;

-- Garante que a view tenha as mesmas políticas RLS da tabela base
-- A view herdará automaticamente as políticas RLS da tabela invoices
COMMENT ON VIEW public.invoices_summary IS 'Summary view of invoices table without SECURITY DEFINER';
