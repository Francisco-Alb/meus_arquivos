
-- Primeiro, criar a tabela user_profiles
CREATE TABLE IF NOT EXISTS public.user_profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  nome TEXT NOT NULL,
  telefone TEXT,
  cargo TEXT NOT NULL CHECK (cargo IN ('gerente_prestacao_contas', 'analista_prestacao_contas', 'analista_pagamento')),
  foto TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar RLS na tabela user_profiles
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
CREATE POLICY "Users can view own profile" ON public.user_profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.user_profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.user_profiles
  FOR UPDATE USING (auth.uid() = id);

-- Função para criar perfil automaticamente quando usuário se registra
CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, nome, cargo)
  VALUES (
    NEW.id, 
    NEW.email, 
    COALESCE(NEW.raw_user_meta_data->>'nome', NEW.email), 
    COALESCE(NEW.raw_user_meta_data->>'cargo', 'analista_prestacao_contas')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para criar perfil automaticamente
DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_profile
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_profile();

-- Função para buscar perfil do usuário
CREATE OR REPLACE FUNCTION public.get_user_profile(user_id UUID)
RETURNS TABLE(
  id UUID,
  email TEXT,
  nome TEXT,
  telefone TEXT,
  cargo TEXT,
  foto TEXT,
  is_active BOOLEAN
)
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 
    up.id,
    up.email,
    up.nome,
    up.telefone,
    up.cargo,
    up.foto,
    up.is_active
  FROM public.user_profiles up
  WHERE up.id = user_id;
$$;

-- Função para atualizar perfil do usuário
CREATE OR REPLACE FUNCTION public.update_user_profile(
  user_id UUID,
  profile_data JSONB
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.user_profiles
  SET 
    nome = COALESCE(profile_data->>'nome', nome),
    telefone = COALESCE(profile_data->>'telefone', telefone),
    cargo = COALESCE(profile_data->>'cargo', cargo),
    foto = COALESCE(profile_data->>'foto', foto),
    is_active = COALESCE((profile_data->>'is_active')::boolean, is_active),
    updated_at = NOW()
  WHERE id = user_id;
END;
$$;
