
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { Tables, TablesInsert, TablesUpdate } from '@/integrations/supabase/types';

export type Credor = Tables<'credores'>;
export type CredorInsert = TablesInsert<'credores'>;
export type CredorUpdate = TablesUpdate<'credores'>;

export const useSupabaseCredores = () => {
  const [credores, setCredores] = useState<Credor[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch credores from Supabase
  const fetchCredores = async () => {
    try {
      const { data, error } = await supabase
        .from('credores')
        .select('*')
        .order('nome');

      if (error) {
        console.error('Error fetching credores:', error);
        toast.error('Erro ao carregar credores');
        return;
      }

      setCredores(data || []);
    } catch (error) {
      console.error('Error fetching credores:', error);
      toast.error('Erro ao carregar credores');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCredores();
  }, []);

  // Add a new credor
  const addCredor = async (newCredor: Omit<CredorInsert, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data, error } = await supabase
        .from('credores')
        .insert([newCredor])
        .select()
        .single();

      if (error) {
        console.error('Error adding credor:', error);
        toast.error('Erro ao cadastrar credor');
        return false;
      }

      setCredores(prev => [...prev, data]);
      toast.success('Credor cadastrado com sucesso');
      return true;
    } catch (error) {
      console.error('Error adding credor:', error);
      toast.error('Erro ao cadastrar credor');
      return false;
    }
  };

  // Edit an existing credor
  const editCredor = async (id: string, updatedCredor: Partial<CredorUpdate>) => {
    try {
      const { data, error } = await supabase
        .from('credores')
        .update(updatedCredor)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('Error updating credor:', error);
        toast.error('Erro ao atualizar credor');
        return false;
      }

      setCredores(prev => prev.map(credor => 
        credor.id === id ? data : credor
      ));
      toast.success('Credor atualizado com sucesso');
      return true;
    } catch (error) {
      console.error('Error updating credor:', error);
      toast.error('Erro ao atualizar credor');
      return false;
    }
  };

  // Delete a credor
  const deleteCredor = async (id: string) => {
    try {
      const { error } = await supabase
        .from('credores')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting credor:', error);
        toast.error('Erro ao excluir credor');
        return false;
      }

      setCredores(prev => prev.filter(credor => credor.id !== id));
      toast.success('Credor excluído com sucesso');
      return true;
    } catch (error) {
      console.error('Error deleting credor:', error);
      toast.error('Erro ao excluir credor');
      return false;
    }
  };

  return {
    credores,
    loading,
    addCredor,
    editCredor,
    deleteCredor,
    refetch: fetchCredores
  };
};
