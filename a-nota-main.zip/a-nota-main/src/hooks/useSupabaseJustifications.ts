
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { Tables, TablesInsert, TablesUpdate } from '@/integrations/supabase/types';

export type Justification = Tables<'justifications'>;
export type JustificationInsert = TablesInsert<'justifications'>;
export type JustificationUpdate = TablesUpdate<'justifications'>;

export const useSupabaseJustifications = () => {
  const [justifications, setJustifications] = useState<Justification[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch justifications from Supabase
  const fetchJustifications = async () => {
    try {
      const { data, error } = await supabase
        .from('justifications')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching justifications:', error);
        toast.error('Erro ao carregar justificativas');
        return;
      }

      setJustifications(data || []);
    } catch (error) {
      console.error('Error fetching justifications:', error);
      toast.error('Erro ao carregar justificativas');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJustifications();
  }, []);

  // Add a new justification
  const addJustification = async (newJustification: Omit<JustificationInsert, 'id' | 'created_at'>) => {
    try {
      const { data, error } = await supabase
        .from('justifications')
        .insert([newJustification])
        .select()
        .single();

      if (error) {
        console.error('Error adding justification:', error);
        toast.error('Erro ao cadastrar justificativa');
        return false;
      }

      setJustifications(prev => [data, ...prev]);
      toast.success('Justificativa cadastrada com sucesso');
      return true;
    } catch (error) {
      console.error('Error adding justification:', error);
      toast.error('Erro ao cadastrar justificativa');
      return false;
    }
  };

  // Update a justification
  const updateJustification = async (id: string, updatedJustification: Partial<JustificationUpdate>) => {
    try {
      const { data, error } = await supabase
        .from('justifications')
        .update(updatedJustification)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('Error updating justification:', error);
        toast.error('Erro ao atualizar justificativa');
        return false;
      }

      setJustifications(prev => prev.map(justification => 
        justification.id === id ? data : justification
      ));
      toast.success('Justificativa atualizada com sucesso');
      return true;
    } catch (error) {
      console.error('Error updating justification:', error);
      toast.error('Erro ao atualizar justificativa');
      return false;
    }
  };

  // Delete a justification
  const deleteJustification = async (id: string) => {
    try {
      const { error } = await supabase
        .from('justifications')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting justification:', error);
        toast.error('Erro ao excluir justificativa');
        return false;
      }

      setJustifications(prev => prev.filter(justification => justification.id !== id));
      toast.success('Justificativa excluída com sucesso');
      return true;
    } catch (error) {
      console.error('Error deleting justification:', error);
      toast.error('Erro ao excluir justificativa');
      return false;
    }
  };

  return {
    justifications,
    loading,
    addJustification,
    updateJustification,
    deleteJustification,
    refetch: fetchJustifications
  };
};
