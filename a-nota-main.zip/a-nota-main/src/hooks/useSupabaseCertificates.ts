
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { Tables, TablesUpdate } from '@/integrations/supabase/types';

export type Certificate = Tables<'certificates'>;
export type CertificateUpdate = TablesUpdate<'certificates'>;

export const useSupabaseCertificates = () => {
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch certificates from Supabase
  const fetchCertificates = async () => {
    try {
      console.log('🔄 Buscando certificados do Supabase...');
      
      const { data, error } = await supabase
        .from('certificates')
        .select('*')
        .order('creditor_name');

      if (error) {
        console.error('❌ Erro ao buscar certificados:', error);
        toast.error('Erro ao carregar certidões');
        return;
      }

      console.log('✅ Certificados carregados:', data);
      setCertificates(data || []);
    } catch (error) {
      console.error('❌ Erro crítico ao buscar certificados:', error);
      toast.error('Erro ao carregar certidões');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, []);

  // Update a certificate
  const updateCertificate = async (id: string, updatedCertificate: Partial<CertificateUpdate>) => {
    try {
      console.log('🔄 Atualizando certificado:', id, updatedCertificate);
      
      const { data, error } = await supabase
        .from('certificates')
        .update(updatedCertificate)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('❌ Erro ao atualizar certificado:', error);
        toast.error('Erro ao atualizar certidão');
        return false;
      }

      console.log('✅ Certificado atualizado:', data);
      setCertificates(prev => prev.map(cert => 
        cert.id === id ? data : cert
      ));
      return true;
    } catch (error) {
      console.error('❌ Erro crítico ao atualizar certificado:', error);
      toast.error('Erro ao atualizar certidão');
      return false;
    }
  };

  return {
    certificates,
    loading,
    updateCertificate,
    refetch: fetchCertificates
  };
};
