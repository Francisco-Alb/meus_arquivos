
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Invoice = Database["public"]["Tables"]["invoices"]["Row"];
type InsertInvoice = Database["public"]["Tables"]["invoices"]["Insert"];

export const useSupabaseInvoices = () => {
  const queryClient = useQueryClient();

  const { data: invoices, isLoading, error, refetch } = useQuery({
    queryKey: ["invoices"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("invoices")
        .select("*")
        .order("created_at", { ascending: false });
      
      if (error) throw error;
      return data as Invoice[];
    },
  });

  const { data: projects } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("projects")
        .select("*");
      
      if (error) throw error;
      return data;
    },
  });

  const addInvoice = useMutation({
    mutationFn: async (invoice: InsertInvoice) => {
      // Add default project_id if not provided
      const invoiceWithProject = {
        ...invoice,
        project_id: invoice.project_id || (projects?.[0]?.id || '00000000-0000-0000-0000-000000000000')
      };
      
      const { data, error } = await supabase
        .from("invoices")
        .insert(invoiceWithProject)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invoices"] });
    },
  });

  const updateInvoice = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Invoice> & { id: string }) => {
      const { data, error } = await supabase
        .from("invoices")
        .update(updates)
        .eq("id", id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invoices"] });
    },
  });

  const deleteInvoice = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("invoices")
        .delete()
        .eq("id", id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invoices"] });
    },
  });

  return {
    invoices: invoices || [],
    projects: projects || [],
    isLoading,
    loading: isLoading,
    error,
    refetch,
    addInvoice: addInvoice.mutateAsync,
    insertInvoice: addInvoice.mutateAsync,
    updateInvoice: updateInvoice.mutateAsync,
    deleteInvoice: deleteInvoice.mutateAsync,
  };
};
