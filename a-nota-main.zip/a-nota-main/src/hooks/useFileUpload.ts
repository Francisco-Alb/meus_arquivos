
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export const useFileUpload = () => {
  const [uploading, setUploading] = useState(false);

  const uploadFile = async (file: File, certificateId: string, docType: string): Promise<string | null> => {
    try {
      setUploading(true);
      
      console.log('=== INICIANDO UPLOAD ===');
      console.log('Arquivo:', { nome: file.name, tamanho: file.size, tipo: file.type });
      console.log('Parâmetros:', { certificateId, docType });
      
      // Validações básicas
      if (!file) {
        console.error('❌ Arquivo não fornecido');
        toast.error('Nenhum arquivo selecionado');
        return null;
      }

      if (file.type !== 'application/pdf') {
        console.error('❌ Tipo de arquivo inválido:', file.type);
        toast.error('Apenas arquivos PDF são permitidos');
        return null;
      }

      if (file.size > 10 * 1024 * 1024) {
        console.error('❌ Arquivo muito grande:', file.size);
        toast.error('Arquivo muito grande. Limite de 10MB');
        return null;
      }

      // Gerar nome único do arquivo
      const timestamp = Date.now();
      const randomId = Math.random().toString(36).substring(2, 15);
      const fileName = `${certificateId}/${docType}_${timestamp}_${randomId}.pdf`;
      
      console.log('📁 Nome do arquivo:', fileName);
      console.log('📁 Bucket: certificates');
      
      // Realizar upload diretamente com o arquivo File
      console.log('⬆️ Iniciando upload...');
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('certificates')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: true,
          contentType: 'application/pdf'
        });

      if (uploadError) {
        console.error('❌ Erro no upload:', uploadError);
        toast.error(`Erro no upload: ${uploadError.message}`);
        return null;
      }

      if (!uploadData || !uploadData.path) {
        console.error('❌ Upload não retornou dados válidos');
        toast.error('Upload falhou - dados inválidos');
        return null;
      }

      console.log('✅ Upload realizado com sucesso!');
      console.log('📄 Caminho:', uploadData.path);

      // Gerar URL pública
      const { data: publicUrlData } = supabase.storage
        .from('certificates')
        .getPublicUrl(uploadData.path);

      if (!publicUrlData?.publicUrl) {
        console.error('❌ Erro ao gerar URL pública');
        toast.error('Erro ao gerar URL do arquivo');
        return null;
      }

      console.log('✅ URL pública:', publicUrlData.publicUrl);
      console.log('=== UPLOAD CONCLUÍDO ===');
      
      toast.success(`Arquivo "${file.name}" enviado com sucesso!`);
      return publicUrlData.publicUrl;
      
    } catch (error) {
      console.error('=== ERRO CRÍTICO ===');
      console.error('Erro:', error);
      toast.error('Erro crítico durante o upload');
      return null;
    } finally {
      setUploading(false);
    }
  };

  const downloadFile = async (filePath: string): Promise<Blob | null> => {
    try {
      console.log('=== INICIANDO DOWNLOAD ===');
      console.log('URL/Caminho:', filePath);
      
      // Extrair o caminho real do arquivo da URL pública
      let actualPath = filePath;
      
      if (filePath.includes('/storage/v1/object/public/certificates/')) {
        actualPath = filePath.split('/storage/v1/object/public/certificates/')[1];
        console.log('Caminho extraído:', actualPath);
      }
      
      const { data, error } = await supabase.storage
        .from('certificates')
        .download(actualPath);

      if (error) {
        console.error('❌ Erro no download:', error);
        toast.error(`Erro ao baixar: ${error.message}`);
        return null;
      }

      if (!data) {
        console.error('❌ Download não retornou dados');
        toast.error('Arquivo não encontrado');
        return null;
      }

      console.log('✅ Download realizado, tamanho:', data.size);
      console.log('=== DOWNLOAD CONCLUÍDO ===');
      return data;
      
    } catch (error) {
      console.error('=== ERRO NO DOWNLOAD ===');
      console.error('Erro:', error);
      toast.error('Erro ao baixar arquivo');
      return null;
    }
  };

  return {
    uploadFile,
    downloadFile,
    uploading
  };
};
