
import React, { useState } from "react";
import Header from "./Header";
import Sidebar from "./Sidebar";
import { useLocation } from "react-router-dom";

interface AppLayoutProps {
  children: React.ReactNode;
  activePath?: string;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children, activePath }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const location = useLocation();
  const currentPath = activePath || location.pathname;

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const shouldPassSearchQuery = !["/", "/cadastro-credores", "/cadastro-notas", "/justificativas", "/certidoes", "/perfil", "/exportar"].includes(location.pathname);

  const childrenToRender = shouldPassSearchQuery
    ? React.Children.map(children, child => {
        if (!React.isValidElement(child)) {
          return child;
        }
        return React.cloneElement(child as React.ReactElement<any>, {
          searchQuery
        });
      })
    : children;

  return (
    <div className="flex h-screen w-full bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20">
      <Sidebar activePath={currentPath} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header onSearch={handleSearch} />
        <main className="flex-1 overflow-y-auto bg-transparent">
          <div className="animate-fade-in">
            {childrenToRender}
          </div>
        </main>
      </div>
    </div>
  );
};

export default AppLayout;
