
import { Bell, Search } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useNotifications } from "@/contexts/NotificationsContext";

interface HeaderProps {
  onSearch?: (query: string) => void;
}

const Header = ({ onSearch }: HeaderProps) => {
  const { userProfile } = useAuth();
  const { unreadCount, notifications, markAllAsRead } = useNotifications();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const location = useLocation();

  const showSearch = ![
    "/", 
    "/cadastro-credores", 
    "/cadastro-notas", 
    "/justificativas", 
    "/certidoes", 
    "/perfil", 
    "/exportar",
    "/avisos"
  ].includes(location.pathname);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    if (onSearch) {
      onSearch(query);
    }
  };

  useEffect(() => {
    setSearchQuery("");
    if (onSearch) {
      onSearch("");
    }
  }, [location.pathname, onSearch]);

  const handleNotificationsClick = () => {
    markAllAsRead();
    navigate("/avisos", { state: { showOnlyUserNotifications: true } });
  };

  // Gerar iniciais do nome
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const recentNotifications = notifications.filter(n => !n.read).slice(0, 3);

  if (!userProfile) {
    return null;
  }

  return (
    <header className="bg-white/80 backdrop-blur-md shadow-sm border-b border-white/20 px-6 py-4 flex justify-between items-center">
      <div className="flex-1">
        {showSearch && (
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input 
              placeholder="Buscar por nº NF, solicitação, credor ou competência..." 
              className="pl-10 pr-4 py-3 rounded-xl border-gray-200 bg-white/70 backdrop-blur-sm focus:bg-white focus:border-blue-300 focus:ring-blue-300/20 transition-all duration-200"
              value={searchQuery}
              onChange={handleSearch}
            />
          </div>
        )}
      </div>

      <div className="flex items-center space-x-4">
        <Popover>
          <PopoverTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className="relative h-10 w-10 rounded-xl hover:bg-blue-50 transition-colors"
              onClick={handleNotificationsClick}
            >
              <Bell size={20} className="text-gray-600" />
              {unreadCount > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-gradient-to-r from-red-500 to-red-600 text-white text-xs font-semibold shadow-lg">
                  {unreadCount}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 bg-white/95 backdrop-blur-md border-gray-200 shadow-xl rounded-xl">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-blue-100">
                  <Bell size={16} className="text-blue-600" />
                </div>
                <h4 className="font-semibold text-gray-900">Notificações</h4>
              </div>
              {recentNotifications.length > 0 ? (
                <div className="space-y-2">
                  {recentNotifications.map((notification) => (
                    <div key={notification.id} className="text-sm text-gray-600 p-2 bg-gray-50 rounded-lg">
                      <p className="font-medium">{notification.title}</p>
                      <p>{notification.message}</p>
                    </div>
                  ))}
                  {unreadCount > 3 && (
                    <p className="text-xs text-gray-500 text-center">
                      e mais {unreadCount - 3} notificações...
                    </p>
                  )}
                </div>
              ) : (
                <p className="text-sm text-gray-600 leading-relaxed">
                  Nenhuma notificação recente.
                </p>
              )}
            </div>
          </PopoverContent>
        </Popover>

        <div className="flex items-center gap-4 pl-4 border-l border-gray-200">
          <div className="flex flex-col items-end">
            <span className="font-semibold text-gray-900">{userProfile.nome}</span>
            <span className="text-sm text-gray-500">{userProfile.cargo}</span>
          </div>
          <Avatar className="h-10 w-10 ring-2 ring-white shadow-lg">
            <AvatarImage src={userProfile.foto || ''} alt={userProfile.nome} />
            <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-semibold">
              {getInitials(userProfile.nome)}
            </AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
};

export default Header;
