import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { 
  Home, 
  Users, 
  FilePlus, 
  FileText, 
  FileSearch, 
  User, 
  BarChart3, 
  LogOut,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useAuth } from "@/contexts/AuthContext";

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  href?: string;
  active?: boolean;
  collapsed?: boolean;
  onClick?: () => void;
}

const SidebarItem = ({ icon, label, href, active, collapsed, onClick }: SidebarItemProps) => {
  const content = (
    <Button
      variant="ghost"
      className={cn(
        "w-full text-gray-300 hover:bg-gray-800 hover:text-white rounded-xl mb-2 p-3 h-12 transition-all duration-200",
        collapsed ? "justify-center" : "justify-start",
        active && "bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg"
      )}
      onClick={onClick}
    >
      <div className={cn("flex items-center", collapsed ? "justify-center" : "")}>
        <div className={cn(collapsed ? "" : "mr-3")}>{icon}</div>
        {!collapsed && <span className="font-medium">{label}</span>}
      </div>
    </Button>
  );

  if (collapsed) {
    return (
      <TooltipProvider delayDuration={0}> 
        <Tooltip>
          <TooltipTrigger asChild>
            {href ? <Link to={href}>{content}</Link> : content}
          </TooltipTrigger>
          <TooltipContent side="right" className="bg-gray-900 text-white border-gray-700">
            <p>{label}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return href ? <Link to={href}>{content}</Link> : content;
};

interface SidebarProps {
  activePath: string;
}

const Sidebar = ({ activePath }: SidebarProps) => {
  const [collapsed, setCollapsed] = useState(false);
  const { signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    console.log('Sidebar: Iniciando logout...');
    try {
      await signOut();
      console.log('Sidebar: Logout realizado com sucesso');
      navigate('/login');
    } catch (error) {
      console.error('Sidebar: Erro no logout:', error);
    }
  };

  const menuItems = [
    {
      icon: <Home size={20} />,
      label: "Início",
      href: "/",
    },
    {
      icon: <Users size={20} />,
      label: "Cadastro de Credores",
      href: "/cadastro-credores",
    },
    {
      icon: <FilePlus size={20} />,
      label: "Cadastro de Notas",
      href: "/cadastro-notas",
    },
    {
      icon: <FileText size={20} />,
      label: "Cadastro de Justificativas",
      href: "/justificativas",
    },
    {
      icon: <FileSearch size={20} />,
      label: "Certidões",
      href: "/certidoes",
    },
    {
      icon: <User size={20} />,
      label: "Perfil",
      href: "/perfil",
    },
    {
      icon: <BarChart3 size={20} />,
      label: "Relatório de Evolução",
      href: "/exportar",
    },
  ];

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  return (
    <div 
      className={cn(
        "h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 flex flex-col transition-all duration-300 shadow-2xl border-r border-gray-700/50",
        collapsed ? "w-20" : "w-72"
      )}
    >
      <div className={cn(
        "p-6 flex items-center mb-8 mt-4",
        collapsed ? "justify-center" : "justify-between"
      )}>
        {!collapsed && (
          <div className="flex items-center gap-3">
            <img 
              src="/lovable-uploads/f3c1cc98-716e-466b-9b14-1be216a7df4d.png" 
              alt="Logo da Empresa" 
              className="h-12 w-auto object-contain"
            />
          </div>
        )}
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleSidebar} 
          className="text-gray-300 hover:text-white hover:bg-gray-800 rounded-xl h-10 w-10 transition-colors"
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </Button>
      </div>
      
      <div className={cn(
        "px-4 py-2 flex-1",
        collapsed && "px-2"
      )}>
        {menuItems.map((item) => (
          <SidebarItem
            key={item.href}
            icon={item.icon}
            label={item.label}
            href={item.href}
            active={item.href === activePath}
            collapsed={collapsed}
          />
        ))}
        
        {/* Botão Sair separado */}
        <SidebarItem
          icon={<LogOut size={20} />}
          label="Sair"
          collapsed={collapsed}
          onClick={handleSignOut}
        />
      </div>

      {/* Footer */}
      <div className={cn(
        "p-4 border-t border-gray-700/50",
        collapsed ? "text-center" : ""
      )}>
        {!collapsed && (
          <div className="text-center">
            <p className="text-xs text-gray-400">Sistema v1.0</p>
            <p className="text-xs text-gray-500 mt-1">© 2024 Todos os direitos reservados</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;
