
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

export type StatusType = 
  | "pendente" 
  | "analise" 
  | "aprovada" 
  | "nao-aprovada" 
  | "corrigida" 
  | "paga";

interface StatusBadgeProps {
  status: StatusType;
  onClick?: () => void;
}

const statusConfig = {
  pendente: {
    color: "bg-red-200 text-gray-800",
    label: "Nota Pendente"
  },
  analise: {
    color: "bg-status-analyzing text-white",
    label: "Em Análise"
  },
  aprovada: {
    color: "bg-status-approved text-white",
    label: "Aprovada"
  },
  "nao-aprovada": {
    color: "bg-status-rejected text-white",
    label: "Não Aprovada"
  },
  corrigida: {
    color: "bg-status-corrected text-white",
    label: "Corrigida"
  },
  paga: {
    color: "bg-status-paid text-white",
    label: "Paga"
  }
};

export const StatusBadge = ({ status, onClick }: StatusBadgeProps) => {
  const config = statusConfig[status];
  
  return (
    <Badge className={cn(
      "rounded-md font-normal px-2.5 py-1 cursor-pointer flex items-center", 
      config.color
    )} onClick={onClick}>
      <span>{config.label}</span>
    </Badge>
  );
};
