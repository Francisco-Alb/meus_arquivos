
import { StatusType } from "./StatusBadge";

// Map of status types to their display labels
const statusLabels = {
  pendente: "Pendente",
  analise: "Em Análise",
  aprovada: "Aprovada",
  "nao-aprovada": "Não Aprovada",
  corrigida: "Corrigida",
  paga: "Paga"
};

interface StatusMenuProps {
  currentStatus: StatusType;
  onSelect: (status: StatusType) => void;
}

export const StatusMenu = ({ currentStatus, onSelect }: StatusMenuProps) => {
  const statusOptions: StatusType[] = ["pendente", "analise", "aprovada", "nao-aprovada", "corrigida", "paga"];

  return (
    <div className="absolute z-10 mt-1 left-0 bg-white rounded-md shadow-lg border border-gray-200 py-1 w-40">
      {statusOptions.map((status) => (
        <div
          key={status}
          className={`px-4 py-2 text-sm hover:bg-gray-100 cursor-pointer ${
            status === currentStatus ? "bg-gray-50 font-medium" : ""
          }`}
          onClick={(e) => {
            e.stopPropagation();
            onSelect(status);
          }}
        >
          {statusLabels[status]}
        </div>
      ))}
    </div>
  );
};
