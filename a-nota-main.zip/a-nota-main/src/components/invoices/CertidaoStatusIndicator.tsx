
import { useSupabaseCertificates } from "@/hooks/useSupabaseCertificates";
import { isAfter, isBefore, parseISO, addDays } from "date-fns";

interface CertidaoStatusIndicatorProps {
  credorName: string;
}

// Função para calcular o status de uma certidão
const calculateCertidaoStatus = (date: string | null): string => {
  if (!date) return "AUSENTE";
  
  try {
    const certDate = typeof date === 'string' ? parseISO(date) : date;
    const today = new Date();
    const tenDaysFromNow = addDays(today, 10);
    
    if (isBefore(certDate, today)) return "VENCIDA";
    if (isBefore(certDate, tenDaysFromNow)) return "A VENCER";
    return "VÁLIDA";
  } catch (error) {
    console.error('Erro ao calcular status da certidão:', error);
    return "VENCIDA";
  }
};

// Função para determinar o status geral do credor
const getCredorCertidaoStatus = (certificate: any): "red" | "orange" | "green" => {
  console.log('=== VERIFICANDO STATUS DO CREDOR ===');
  console.log('Certificado encontrado:', certificate);
  
  if (!certificate) {
    console.log('❌ Nenhum certificado encontrado');
    return "red";
  }

  const certidoes = [
    { tipo: 'Municipal', date: certificate.municipal_date },
    { tipo: 'Estadual', date: certificate.estadual_date },
    { tipo: 'Federal', date: certificate.federal_date },
    { tipo: 'Trabalhista', date: certificate.trabalhista_date },
    { tipo: 'FGTS', date: certificate.fgts_date }
  ];

  console.log('Certidões a verificar:', certidoes);

  let hasVencida = false;
  let hasAVencer = false;
  let hasValida = false;

  certidoes.forEach(certidao => {
    const status = calculateCertidaoStatus(certidao.date);
    console.log(`${certidao.tipo}: ${certidao.date} -> Status: ${status}`);
    
    if (status === "VENCIDA" || status === "AUSENTE") {
      hasVencida = true;
    } else if (status === "A VENCER") {
      hasAVencer = true;
    } else if (status === "VÁLIDA") {
      hasValida = true;
    }
  });

  console.log('Resumo:', { hasVencida, hasAVencer, hasValida });

  // Se tem pelo menos uma vencida ou ausente, retorna vermelho
  if (hasVencida) {
    console.log('🔴 Status: VERMELHO (tem vencidas/ausentes)');
    return "red";
  }
  
  // Se tem pelo menos uma a vencer, retorna laranja
  if (hasAVencer) {
    console.log('🟠 Status: LARANJA (tem a vencer)');
    return "orange";
  }
  
  // Se todas estão válidas, retorna verde
  console.log('🟢 Status: VERDE (todas válidas)');
  return "green";
};

export const CertidaoStatusIndicator = ({ credorName }: CertidaoStatusIndicatorProps) => {
  const { certificates, loading } = useSupabaseCertificates();
  
  console.log('=== INDICADOR CND ===');
  console.log('Credor buscado:', credorName);
  console.log('Certificados disponíveis:', certificates);
  console.log('Loading:', loading);
  
  if (loading) {
    return (
      <div 
        className="w-3 h-3 rounded-full bg-gray-300 animate-pulse" 
        title="Carregando status das certidões..."
      />
    );
  }

  // Busca mais flexível pelo credor
  const credorCertificate = certificates.find(cert => {
    const nomeMatch = cert.creditor_name?.toLowerCase().includes(credorName.toLowerCase());
    const cnpjMatch = cert.creditor_cnpj && credorName.includes(cert.creditor_cnpj);
    return nomeMatch || cnpjMatch;
  });

  console.log('Certificado encontrado para', credorName, ':', credorCertificate);

  if (!credorCertificate) {
    console.log('❌ Credor não encontrado no sistema de certidões');
    return (
      <div 
        className="w-3 h-3 rounded-full bg-red-500" 
        title="Credor não encontrado no sistema de certidões"
      />
    );
  }

  const status = getCredorCertidaoStatus(credorCertificate);
  
  const statusConfig = {
    red: {
      color: "bg-red-500",
      title: "Possui certidões vencidas ou ausentes"
    },
    orange: {
      color: "bg-orange-500", 
      title: "Possui certidões a vencer em breve"
    },
    green: {
      color: "bg-green-500",
      title: "Todas as certidões estão válidas"
    }
  };

  console.log('Status final:', status, statusConfig[status].title);
  console.log('=== FIM INDICADOR CND ===');

  return (
    <div 
      className={`w-3 h-3 rounded-full ${statusConfig[status].color}`}
      title={statusConfig[status].title}
    />
  );
};
