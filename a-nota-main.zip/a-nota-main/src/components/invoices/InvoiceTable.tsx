
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { StatusBadge, StatusType } from "./StatusBadge";
import { CertidaoStatusIndicator } from "./CertidaoStatusIndicator";
import { formatCurrency } from "@/lib/formatters";
import { useState, useEffect } from "react";
import { StatusMenu } from "./StatusMenu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Check, Edit, Minus } from "lucide-react";
import { toast } from "sonner";
import { useSupabaseJustifications } from "@/hooks/useSupabaseJustifications";

export interface Invoice {
  id: string;
  requestNumber: string;
  creditor: string;
  invoiceNumber: string;
  competence: string;
  value: number;
  status: StatusType;
  observation: string;
  species: string;
  createdAt?: Date;
}

interface InvoiceTableProps {
  invoices: Invoice[];
  onStatusChange?: (invoiceId: string, newStatus: StatusType) => void;
  onObservationChange?: (invoiceId: string, newObservation: string) => void;
  onRequestNumberChange?: (invoiceId: string, newRequestNumber: string) => void;
}

export const InvoiceTable = ({ 
  invoices, 
  onStatusChange,
  onObservationChange,
  onRequestNumberChange
}: InvoiceTableProps) => {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const { justifications } = useSupabaseJustifications();
  const [isJustificationDialogOpen, setIsJustificationDialogOpen] = useState(false);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);
  const [editingRequestNumber, setEditingRequestNumber] = useState<string | null>(null);
  const [editRequestNumberValue, setEditRequestNumberValue] = useState("");

  const handleStatusClick = (invoiceId: string) => {
    setActiveDropdown(activeDropdown === invoiceId ? null : invoiceId);
  };

  const handleStatusChange = (invoiceId: string, newStatus: StatusType) => {
    if (onStatusChange) {
      onStatusChange(invoiceId, newStatus);
    }
    setActiveDropdown(null);
  };

  const handleObservationClick = (invoiceId: string) => {
    setSelectedInvoiceId(invoiceId);
    setIsJustificationDialogOpen(true);
  };

  const handleJustificationSelect = (text: string) => {
    if (selectedInvoiceId !== null && onObservationChange) {
      onObservationChange(selectedInvoiceId, text);
      setIsJustificationDialogOpen(false);
      setSelectedInvoiceId(null);
      toast.success("Justificativa atualizada com sucesso");
    }
  };

  const handleRequestNumberEdit = (invoiceId: string, currentValue: string) => {
    setEditingRequestNumber(invoiceId);
    setEditRequestNumberValue(currentValue);
  };

  const handleRequestNumberSave = (invoiceId: string) => {
    if (onRequestNumberChange && editRequestNumberValue.trim()) {
      onRequestNumberChange(invoiceId, editRequestNumberValue.trim());
      toast.success("Número de solicitação atualizado com sucesso");
    }
    setEditingRequestNumber(null);
    setEditRequestNumberValue("");
  };

  const handleRequestNumberCancel = () => {
    setEditingRequestNumber(null);
    setEditRequestNumberValue("");
  };

  const formatRequestNumber = (requestNumber: string): string => {
    if (!/^\d{9}$/.test(requestNumber)) {
      const numbers = requestNumber.replace(/\D/g, '');
      if (numbers.length >= 9) {
        return numbers.substring(0, 9);
      }
      return numbers.padStart(9, '0');
    }
    return requestNumber;
  };

  const formatInvoiceNumber = (invoiceNumber: string): string => {
    return invoiceNumber.replace(/\D/g, '');
  };

  // Sort invoices by competence (most recent first)
  const sortedInvoices = [...invoices].sort((a, b) => {
    try {
      const [monthA, yearA] = a.competence.split('/').map(Number);
      const [monthB, yearB] = b.competence.split('/').map(Number);
      
      if (yearA !== yearB) {
        return yearB - yearA;
      }
      return monthB - monthA;
    } catch (error) {
      return b.competence.localeCompare(a.competence);
    }
  });

  return (
    <>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-left w-12">CND</TableHead>
              <TableHead className="text-left">Solicitação</TableHead>
              <TableHead className="text-left">Credor</TableHead>
              <TableHead className="text-left">Nº NF</TableHead>
              <TableHead className="text-left">Competência</TableHead>
              <TableHead className="text-left">Valor</TableHead>
              <TableHead className="text-left">Tipo</TableHead>
              <TableHead className="text-center">Status</TableHead>
              <TableHead className="text-left">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedInvoices.map((invoice) => (
              <TableRow key={invoice.id}>
                <TableCell className="text-center">
                  <CertidaoStatusIndicator credorName={invoice.creditor} />
                </TableCell>
                <TableCell className="font-medium text-left">
                  {editingRequestNumber === invoice.id ? (
                    <div className="flex items-center gap-2">
                      <Input
                        value={editRequestNumberValue}
                        onChange={(e) => setEditRequestNumberValue(e.target.value)}
                        className="w-32"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            handleRequestNumberSave(invoice.id);
                          } else if (e.key === 'Escape') {
                            handleRequestNumberCancel();
                          }
                        }}
                        autoFocus
                      />
                      <Button
                        size="sm"
                        onClick={() => handleRequestNumberSave(invoice.id)}
                        className="h-8 w-8 p-0"
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleRequestNumberCancel}
                        className="h-8 w-8 p-0"
                      >
                        ✕
                      </Button>
                    </div>
                  ) : (
                    <div 
                      className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded"
                      onClick={() => handleRequestNumberEdit(invoice.id, invoice.requestNumber)}
                    >
                      <span>{formatRequestNumber(invoice.requestNumber)}</span>
                      <Edit className="h-3 w-3 text-gray-400" />
                    </div>
                  )}
                </TableCell>
                <TableCell className="text-left">{invoice.creditor}</TableCell>
                <TableCell className="text-left">{formatInvoiceNumber(invoice.invoiceNumber)}</TableCell>
                <TableCell className="text-left">{invoice.competence}</TableCell>
                <TableCell className="text-left">{formatCurrency(invoice.value)}</TableCell>
                <TableCell className="text-left">{invoice.species || "-"}</TableCell>
                <TableCell className="text-center relative">
                  <div onClick={() => handleStatusClick(invoice.id)} className="flex justify-center">
                    <StatusBadge status={invoice.status} />
                  </div>
                  {activeDropdown === invoice.id && (
                    <StatusMenu 
                      currentStatus={invoice.status}
                      onSelect={(newStatus) => handleStatusChange(invoice.id, newStatus)}
                    />
                  )}
                </TableCell>
                <TableCell className="text-left">
                  <div 
                    className="flex items-center cursor-pointer" 
                    onClick={() => handleObservationClick(invoice.id)}
                  >
                    {invoice.observation ? (
                      <>
                        <span className="text-sm text-gray-500 mr-2">{invoice.observation}</span>
                        <Edit className="h-4 w-4 text-blue-500" />
                      </>
                    ) : (
                      <>
                        <Minus className="h-4 w-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-400">Sem justificativa</span>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Justification Selection Dialog */}
      <Dialog open={isJustificationDialogOpen} onOpenChange={setIsJustificationDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Selecione uma justificativa</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="max-h-[300px] overflow-y-auto">
              {justifications.map((justification) => (
                <Button
                  key={justification.id}
                  variant="ghost"
                  className="w-full justify-start h-auto py-3 mb-1 hover:bg-gray-100"
                  onClick={() => handleJustificationSelect(justification.text)}
                >
                  <div className="flex items-center w-full">
                    <span className="flex-1 text-left">{justification.text}</span>
                    <Check className="h-4 w-4 opacity-0 group-hover:opacity-100" />
                  </div>
                </Button>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsJustificationDialogOpen(false)}>
              Cancelar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
