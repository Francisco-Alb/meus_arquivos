
import { Circle, CircleCheck, CircleX, CircleMinus, Clock, CircleDollarSign } from "lucide-react";
import { cn } from "@/lib/utils";
import { StatusType } from "./StatusBadge";

interface StatusCardProps {
  type: StatusType;
  count: number;
  active?: boolean;
  onClick?: () => void;
}

const statusConfig = {
  pendente: {
    icon: Clock,
    label: "Pendentes",
    color: "text-status-pending",
    bgColor: "bg-status-pending/10",
    activeColor: "bg-status-pending"
  },
  analise: {
    icon: Circle,
    label: "Em Análise",
    color: "text-status-analyzing",
    bgColor: "bg-status-analyzing/10",
    activeColor: "bg-status-analyzing"
  },
  aprovada: {
    icon: CircleCheck,
    label: "Aprovadas",
    color: "text-status-approved",
    bgColor: "bg-status-approved/10",
    activeColor: "bg-status-approved"
  },
  "nao-aprovada": {
    icon: CircleX,
    label: "Não Aprovadas",
    color: "text-status-rejected",
    bgColor: "bg-status-rejected/10",
    activeColor: "bg-status-rejected"
  },
  corrigida: {
    icon: CircleMinus,
    label: "Corrigidas",
    color: "text-status-corrected",
    bgColor: "bg-status-corrected/10",
    activeColor: "bg-status-corrected"
  },
  paga: {
    icon: CircleDollarSign,
    label: "Pagas",
    color: "text-status-paid",
    bgColor: "bg-status-paid/10",
    activeColor: "bg-status-paid"
  }
};

export const StatusCard = ({ type, count, active = false, onClick }: StatusCardProps) => {
  const config = statusConfig[type];
  const Icon = config.icon;
  
  return (
    <div 
      className={cn(
        "flex items-center gap-3 p-4 rounded-lg cursor-pointer transition-all",
        active ? `${config.activeColor} text-white` : `${config.bgColor} ${config.color}`
      )}
      onClick={onClick}
    >
      <div className={cn(
        "p-2 rounded-full",
        active ? "bg-white/20" : "bg-white"
      )}>
        <Icon size={24} className={active ? "text-white" : config.color} />
      </div>
      <div>
        <p className="text-sm font-medium">{config.label}</p>
        <p className="text-2xl font-bold">{count}</p>
      </div>
    </div>
  );
};
