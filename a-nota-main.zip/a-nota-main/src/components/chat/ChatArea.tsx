import { supabase } from "@/integrations/supabase/client";
import React, { useState, useRef, useEffect } from "react";
import { Send, Paperclip, Mic, MicOff, Image } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useChat } from "@/contexts/ChatContext";
import { Textarea } from "@/components/ui/textarea";

interface ChatAreaProps {
  selectedChat: string | null;
}

const ChatArea = ({ selectedChat }: ChatAreaProps) => {
  const { contacts, sendMessage, getMessagesForChat } = useChat();
  const [message, setMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedContact = contacts.find(c => c.id === selectedChat);
  const messages = selectedChat ? getMessagesForChat(selectedChat) : [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (message.trim() && selectedChat) {
      sendMessage(selectedChat, message.trim(), 'text');
      setMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handlePdfUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];

    if (!file) {
      console.log('Nenhum arquivo selecionado');
      return;
    }

    console.log('=== UPLOAD DO CHAT ===');
    console.log('Arquivo:', { nome: file.name, tipo: file.type, tamanho: file.size });

    if (file.type !== "application/pdf") {
      console.error('Tipo inválido:', file.type);
      alert("Apenas arquivos PDF são permitidos.");
      e.target.value = '';
      return;
    }

    if (!selectedChat) {
      console.error('Nenhuma conversa selecionada');
      alert("Nenhuma conversa selecionada.");
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      console.error('Arquivo muito grande:', file.size);
      alert("Arquivo muito grande. Limite de 10MB.");
      e.target.value = '';
      return;
    }

    setIsUploading(true);

    try {
      const timestamp = Date.now();
      const randomId = Math.random().toString(36).substring(2, 15);
      const fileName = `chat/${selectedChat}_${timestamp}_${randomId}.pdf`;

      console.log('Nome do arquivo:', fileName);

      const { data, error } = await supabase.storage
        .from("certificates")
        .upload(fileName, file, {
          cacheControl: "3600",
          upsert: true,
          contentType: "application/pdf"
        });

      if (error) {
        console.error("❌ Erro ao enviar PDF:", error);
        alert(`Erro ao enviar arquivo: ${error.message}`);
        return;
      }

      if (!data?.path) {
        console.error("❌ Upload sem dados válidos:", data);
        alert("Erro: Upload não concluído.");
        return;
      }

      console.log('✅ Upload realizado:', data);

      const publicUrl = supabase.storage
        .from("certificates")
        .getPublicUrl(fileName).data.publicUrl;

      console.log('✅ URL pública:', publicUrl);

      if (selectedChat && publicUrl) {
        sendMessage(selectedChat, publicUrl, "text");
        console.log('✅ Mensagem enviada');
      }

    } catch (error) {
      console.error('❌ Erro crítico:', error);
      alert("Erro crítico ao processar arquivo.");
    } finally {
      setIsUploading(false);
      e.target.value = '';
    }
  };

  const toggleRecording = () => {
    if (isRecording) {
      // Simular fim da gravação
      setIsRecording(false);
      if (selectedChat) {
        sendMessage(selectedChat, "audio-data-placeholder", 'audio');
      }
    } else {
      // Simular início da gravação
      setIsRecording(true);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  if (!selectedChat) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
            <Send className="w-12 h-12 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-700 mb-2">
            Selecione uma conversa
          </h3>
          <p className="text-gray-500">
            Escolha uma conversa na barra lateral para começar a enviar mensagens
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-white">
      {/* Header da conversa */}
      <div className="p-4 border-b border-gray-200 bg-white">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Avatar className="h-10 w-10">
              <AvatarImage src={selectedContact?.avatar} alt={selectedContact?.name} />
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-semibold">
                {selectedContact ? getInitials(selectedContact.name) : ''}
              </AvatarFallback>
            </Avatar>
            {selectedContact?.online && (
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
            )}
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{selectedContact?.name}</h3>
            <p className="text-sm text-gray-500">
              {selectedContact?.online ? 'Online' : 'Offline'}
            </p>
          </div>
        </div>
      </div>

      {/* Área de mensagens */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.senderId === 'current-user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                msg.senderId === 'current-user'
                  ? 'bg-blue-500 text-white'
                  : 'bg-white text-gray-900 border border-gray-200'
              }`}
            >
              {msg.type === 'text' && (
                <p className="whitespace-pre-wrap">{msg.content}</p>
              )}
              {msg.type === 'image' && (
                <div>
                  <img 
                    src={msg.content} 
                    alt="Imagem enviada" 
                    className="rounded-lg max-w-full h-auto"
                  />
                </div>
              )}
              {msg.type === 'audio' && (
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                    <Mic className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="w-32 h-2 bg-blue-300 rounded-full">
                      <div className="w-16 h-2 bg-blue-600 rounded-full"></div>
                    </div>
                  </div>
                  <span className="text-xs opacity-70">0:15</span>
                </div>
              )}
              <div className={`text-xs mt-1 ${
                msg.senderId === 'current-user' ? 'text-blue-100' : 'text-gray-500'
              }`}>
                {formatTime(msg.timestamp)}
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Área de input */}
      <div className="p-4 border-t border-gray-200 bg-white">
        <div className="flex items-end space-x-2">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            className="shrink-0"
            disabled={isUploading}
          >
            <Paperclip size={20} />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            className="shrink-0"
            disabled={isUploading}
          >
            <Image size={20} />
          </Button>

          <div className="flex-1">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={isUploading ? "Enviando arquivo..." : "Digite uma mensagem..."}
              className="min-h-[40px] max-h-32 resize-none border-gray-200 rounded-xl"
              rows={1}
              disabled={isUploading}
            />
          </div>

          {message.trim() ? (
            <Button 
              onClick={handleSendMessage}
              className="shrink-0 bg-blue-500 hover:bg-blue-600 text-white rounded-full h-10 w-10 p-0"
              disabled={isUploading}
            >
              <Send size={18} />
            </Button>
          ) : (
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleRecording}
              className={`shrink-0 ${isRecording ? 'text-red-500' : ''}`}
              disabled={isUploading}
            >
              {isRecording ? <MicOff size={20} /> : <Mic size={20} />}
            </Button>
          )}
        </div>
        
        {isUploading && (
          <div className="mt-2 text-center text-sm text-blue-600">
            Enviando arquivo...
          </div>
        )}
      </div>

      <input
        type="file"
        ref={fileInputRef}
        onChange={handlePdfUpload}
        accept="application/pdf"
        className="hidden"
      />
    </div>
  );
};

export default ChatArea;
