
import React from "react";
import { Filter } from "lucide-react";
import { StatusType } from "@/components/invoices/StatusBadge";
import { Button } from "@/components/ui/button";

interface StatusFilterProps {
  selectedFilter: StatusType | null;
  onFilterChange: (status: StatusType | null) => void;
}

export const StatusFilterMenu: React.FC<StatusFilterProps> = ({ selectedFilter, onFilterChange }) => {
  const statuses: { key: StatusType; color: string; label: string }[] = [
    { key: "pendente", color: "bg-red-200", label: "P" },
    { key: "analise", color: "bg-orange-300", label: "A" },
    { key: "aprovada", color: "bg-green-500", label: "V" },
    { key: "nao-aprovada", color: "bg-red-500", label: "X" },
    { key: "corrigida", color: "bg-purple-400", label: "C" },
    { key: "paga", color: "bg-blue-400", label: "S" }
  ];

  return (
    <div className="flex items-center gap-1">
      {statuses.map((status) => (
        <Button
          key={status.key}
          className={`rounded-full h-8 w-8 p-0 text-white ${status.color} ${
            selectedFilter === status.key ? "ring-2 ring-black" : ""
          }`}
          onClick={() => onFilterChange(selectedFilter === status.key ? null : status.key)}
        >
          {status.label}
        </Button>
      ))}
    </div>
  );
};
