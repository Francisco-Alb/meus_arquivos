
import React, { createContext, useContext, useState, useEffect } from 'react';

interface UserData {
  id: string;
  nome: string;
  email: string;
  cargo: string;
  telefone?: string;
  foto?: string;
}

interface UserContextType {
  userData: UserData;
  setUserData: (data: UserData) => void;
  updateUserData: (data: Partial<UserData>) => void;
  isLoading: boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

interface UserProviderProps {
  children: React.ReactNode;
}

export const UserProvider: React.FC<UserProviderProps> = ({ children }) => {
  const [userData, setUserData] = useState<UserData>({
    id: '1',
    nome: 'Usuário Padrão',
    email: 'usuario@sistema.com',
    cargo: 'Analista',
    telefone: '',
    foto: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    console.log('User context initialized with default data');
  }, []);

  const updateUserData = (data: Partial<UserData>) => {
    setUserData(prev => ({ ...prev, ...data }));
  };

  const value = {
    userData,
    setUserData,
    updateUserData,
    isLoading
  };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};
