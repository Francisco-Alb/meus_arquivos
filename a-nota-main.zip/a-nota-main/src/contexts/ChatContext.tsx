
import React, { createContext, useContext, useState, useEffect } from 'react';

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  type: 'text' | 'image' | 'audio';
  timestamp: Date;
  chatId: string;
}

export interface ChatContact {
  id: string;
  name: string;
  avatar: string;
  lastMessage?: string;
  lastMessageTime?: Date;
  unreadCount: number;
  online: boolean;
}

interface ChatContextType {
  contacts: ChatContact[];
  messages: Message[];
  sendMessage: (chatId: string, content: string, type: 'text' | 'image' | 'audio') => void;
  getMessagesForChat: (chatId: string) => Message[];
}

const defaultContacts: ChatContact[] = [
  {
    id: "1",
    name: "Maria Silva",
    avatar: "",
    lastMessage: "Olá! Como está o processo das notas fiscais?",
    lastMessageTime: new Date(),
    unreadCount: 2,
    online: true
  },
  {
    id: "2", 
    name: "Carlos Santos",
    avatar: "",
    lastMessage: "Preciso enviar alguns documentos",
    lastMessageTime: new Date(Date.now() - 1000 * 60 * 30),
    unreadCount: 0,
    online: false
  },
  {
    id: "3",
    name: "Ana Costa",
    avatar: "",
    lastMessage: "Obrigada pela ajuda!",
    lastMessageTime: new Date(Date.now() - 1000 * 60 * 60 * 2),
    unreadCount: 1,
    online: true
  }
];

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [contacts, setContacts] = useState<ChatContact[]>(defaultContacts);
  const [messages, setMessages] = useState<Message[]>([]);

  // Carregar mensagens do localStorage
  useEffect(() => {
    const savedMessages = localStorage.getItem('chatMessages');
    if (savedMessages) {
      try {
        const parsedMessages = JSON.parse(savedMessages).map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        }));
        setMessages(parsedMessages);
      } catch (error) {
        console.error('Erro ao carregar mensagens:', error);
      }
    }
  }, []);

  // Salvar mensagens no localStorage
  useEffect(() => {
    localStorage.setItem('chatMessages', JSON.stringify(messages));
  }, [messages]);

  const sendMessage = (chatId: string, content: string, type: 'text' | 'image' | 'audio') => {
    const newMessage: Message = {
      id: Date.now().toString(),
      senderId: "current-user",
      senderName: "Você",
      content,
      type,
      timestamp: new Date(),
      chatId
    };

    setMessages(prev => [...prev, newMessage]);

    // Atualizar última mensagem do contato
    setContacts(prev => prev.map(contact => 
      contact.id === chatId 
        ? { 
            ...contact, 
            lastMessage: type === 'text' ? content : type === 'image' ? '📷 Imagem' : '🎵 Áudio',
            lastMessageTime: new Date()
          }
        : contact
    ));
  };

  const getMessagesForChat = (chatId: string) => {
    return messages.filter(message => message.chatId === chatId);
  };

  return (
    <ChatContext.Provider value={{
      contacts,
      messages,
      sendMessage,
      getMessagesForChat
    }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat deve ser usado dentro de um ChatProvider');
  }
  return context;
};
