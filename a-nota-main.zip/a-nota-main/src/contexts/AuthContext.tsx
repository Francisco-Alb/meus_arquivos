
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

interface UserProfile {
  id: string;
  email: string;
  nome: string;
  telefone?: string;
  cargo: 'gerente_prestacao_contas' | 'analista_prestacao_contas' | 'analista_pagamento';
  foto?: string;
  is_active: boolean;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  userProfile: UserProfile | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, userData: Partial<UserProfile>) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  updateProfile: (data: Partial<UserProfile>) => Promise<{ error: any }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isInitialized, setIsInitialized] = useState(false);

  const fetchUserProfile = async (userId: string) => {
    try {
      console.log('AuthProvider: Buscando perfil do usuário:', userId);
      const { data: profile, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('AuthProvider: Erro ao buscar perfil:', error);
        return null;
      }

      if (profile) {
        console.log('AuthProvider: Perfil encontrado:', profile);
        setUserProfile(profile as UserProfile);
        return profile;
      }
    } catch (error) {
      console.error('AuthProvider: Erro inesperado ao buscar perfil:', error);
    }
    return null;
  };

  useEffect(() => {
    let mounted = true;
    
    const initializeAuth = async () => {
      try {
        console.log('AuthProvider: Inicializando autenticação');
        
        // Primeiro, configurar o listener
        const { data: { subscription } } = supabase.auth.onAuthStateChange(
          async (event, session) => {
            if (!mounted) return;
            
            console.log('AuthProvider: Auth state changed:', event, !!session);
            
            setSession(session);
            setUser(session?.user ?? null);

            if (session?.user && event === 'SIGNED_IN') {
              await fetchUserProfile(session.user.id);
            } else if (event === 'SIGNED_OUT') {
              setUserProfile(null);
            }
            
            // Só marcar como não carregando após o primeiro evento
            if (!isInitialized) {
              setIsInitialized(true);
              setIsLoading(false);
            }
          }
        );

        // Depois, verificar sessão existente
        const { data: { session: currentSession } } = await supabase.auth.getSession();
        
        if (!mounted) return;
        
        console.log('AuthProvider: Sessão inicial verificada:', !!currentSession);
        
        setSession(currentSession);
        setUser(currentSession?.user ?? null);

        if (currentSession?.user) {
          await fetchUserProfile(currentSession.user.id);
        }

        setIsInitialized(true);
        setIsLoading(false);

        return () => {
          mounted = false;
          subscription.unsubscribe();
        };
      } catch (error) {
        console.error('AuthProvider: Erro na inicialização:', error);
        if (mounted) {
          setIsLoading(false);
          setIsInitialized(true);
        }
      }
    };

    initializeAuth();

    return () => {
      mounted = false;
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    console.log('AuthProvider: Tentando fazer login para:', email);
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      return { error };
    } catch (error) {
      console.error('AuthProvider: Erro inesperado no login:', error);
      return { error };
    }
  };

  const signUp = async (email: string, password: string, userData: Partial<UserProfile>) => {
    console.log('AuthProvider: Iniciando cadastro para:', email);
    
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            nome: userData.nome,
            telefone: userData.telefone || null,
            cargo: userData.cargo || 'gerente_prestacao_contas'
          },
          emailRedirectTo: `${window.location.origin}/`
        }
      });

      if (error) {
        console.error('AuthProvider: Erro no cadastro Supabase:', error);
        let errorMessage = 'Erro no cadastro';
        if (error.message === 'User already registered') {
          errorMessage = 'Este email já está cadastrado';
        } else if (error.message?.includes('Invalid email')) {
          errorMessage = 'Email inválido';
        } else if (error.message?.includes('Password')) {
          errorMessage = 'Senha deve ter pelo menos 6 caracteres';
        } else {
          errorMessage = error.message || 'Erro desconhecido no cadastro';
        }
        return { error: new Error(errorMessage) };
      }

      console.log('AuthProvider: Cadastro realizado com sucesso!', data);
      return { error: null };
    } catch (error) {
      console.error('AuthProvider: Erro inesperado no cadastro:', error);
      return { error: new Error('Erro inesperado: ' + (error as Error).message) };
    }
  };

  const signOut = async () => {
    console.log('AuthProvider: Fazendo logout');
    const { error } = await supabase.auth.signOut();
    if (!error) {
      setUser(null);
      setSession(null);
      setUserProfile(null);
    }
  };

  const updateProfile = async (data: Partial<UserProfile>) => {
    if (!user) return { error: new Error('Not authenticated') };

    try {
      const { error } = await supabase
        .from('user_profiles')
        .update(data)
        .eq('id', user.id);

      if (!error && userProfile) {
        setUserProfile({ ...userProfile, ...data });
      }

      return { error };
    } catch (error) {
      return { error };
    }
  };

  const value = {
    user,
    session,
    userProfile,
    isLoading,
    signIn,
    signUp,
    signOut,
    updateProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
