export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      certificates: {
        Row: {
          created_at: string
          creditor_cnpj: string
          creditor_id: string | null
          creditor_name: string
          estadual_date: string | null
          estadual_file_path: string | null
          estadual_status:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          federal_date: string | null
          federal_file_path: string | null
          federal_status:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          fgts_date: string | null
          fgts_file_path: string | null
          fgts_status: Database["public"]["Enums"]["certificate_status"] | null
          id: string
          municipal_date: string | null
          municipal_file_path: string | null
          municipal_status:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          trabalhista_date: string | null
          trabalhista_file_path: string | null
          trabalhista_status:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          creditor_cnpj: string
          creditor_id?: string | null
          creditor_name: string
          estadual_date?: string | null
          estadual_file_path?: string | null
          estadual_status?:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          federal_date?: string | null
          federal_file_path?: string | null
          federal_status?:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          fgts_date?: string | null
          fgts_file_path?: string | null
          fgts_status?: Database["public"]["Enums"]["certificate_status"] | null
          id?: string
          municipal_date?: string | null
          municipal_file_path?: string | null
          municipal_status?:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          trabalhista_date?: string | null
          trabalhista_file_path?: string | null
          trabalhista_status?:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          creditor_cnpj?: string
          creditor_id?: string | null
          creditor_name?: string
          estadual_date?: string | null
          estadual_file_path?: string | null
          estadual_status?:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          federal_date?: string | null
          federal_file_path?: string | null
          federal_status?:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          fgts_date?: string | null
          fgts_file_path?: string | null
          fgts_status?: Database["public"]["Enums"]["certificate_status"] | null
          id?: string
          municipal_date?: string | null
          municipal_file_path?: string | null
          municipal_status?:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          trabalhista_date?: string | null
          trabalhista_file_path?: string | null
          trabalhista_status?:
            | Database["public"]["Enums"]["certificate_status"]
            | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "certificates_creditor_id_fkey"
            columns: ["creditor_id"]
            isOneToOne: false
            referencedRelation: "credores"
            referencedColumns: ["id"]
          },
        ]
      }
      credores: {
        Row: {
          cnpj: string
          created_at: string
          id: string
          nome: string
          updated_at: string
        }
        Insert: {
          cnpj: string
          created_at?: string
          id?: string
          nome: string
          updated_at?: string
        }
        Update: {
          cnpj?: string
          created_at?: string
          id?: string
          nome?: string
          updated_at?: string
        }
        Relationships: []
      }
      invoices: {
        Row: {
          competence: string
          created_at: string
          creditor_cnpj: string
          creditor_id: string | null
          creditor_name: string
          id: string
          invoice_number: string
          observation: string | null
          owner: string | null
          project_id: string
          request_number: string
          species: Database["public"]["Enums"]["invoice_species"] | null
          status: Database["public"]["Enums"]["invoice_status"]
          updated_at: string
          value: number
        }
        Insert: {
          competence: string
          created_at?: string
          creditor_cnpj: string
          creditor_id?: string | null
          creditor_name: string
          id?: string
          invoice_number: string
          observation?: string | null
          owner?: string | null
          project_id: string
          request_number: string
          species?: Database["public"]["Enums"]["invoice_species"] | null
          status?: Database["public"]["Enums"]["invoice_status"]
          updated_at?: string
          value: number
        }
        Update: {
          competence?: string
          created_at?: string
          creditor_cnpj?: string
          creditor_id?: string | null
          creditor_name?: string
          id?: string
          invoice_number?: string
          observation?: string | null
          owner?: string | null
          project_id?: string
          request_number?: string
          species?: Database["public"]["Enums"]["invoice_species"] | null
          status?: Database["public"]["Enums"]["invoice_status"]
          updated_at?: string
          value?: number
        }
        Relationships: [
          {
            foreignKeyName: "invoices_creditor_id_fkey"
            columns: ["creditor_id"]
            isOneToOne: false
            referencedRelation: "credores"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      justifications: {
        Row: {
          created_at: string
          id: string
          text: string
        }
        Insert: {
          created_at?: string
          id?: string
          text: string
        }
        Update: {
          created_at?: string
          id?: string
          text?: string
        }
        Relationships: []
      }
      projects: {
        Row: {
          company_id: string | null
          contract_number: string | null
          created_at: string
          description: string | null
          end_date: string | null
          id: string
          name: string
          start_date: string | null
          status: string | null
          updated_at: string
        }
        Insert: {
          company_id?: string | null
          contract_number?: string | null
          created_at?: string
          description?: string | null
          end_date?: string | null
          id?: string
          name: string
          start_date?: string | null
          status?: string | null
          updated_at?: string
        }
        Update: {
          company_id?: string | null
          contract_number?: string | null
          created_at?: string
          description?: string | null
          end_date?: string | null
          id?: string
          name?: string
          start_date?: string | null
          status?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      user_profiles: {
        Row: {
          cargo: string
          created_at: string | null
          email: string
          foto: string | null
          id: string
          is_active: boolean | null
          nome: string
          telefone: string | null
          updated_at: string | null
        }
        Insert: {
          cargo: string
          created_at?: string | null
          email: string
          foto?: string | null
          id: string
          is_active?: boolean | null
          nome: string
          telefone?: string | null
          updated_at?: string | null
        }
        Update: {
          cargo?: string
          created_at?: string | null
          email?: string
          foto?: string | null
          id?: string
          is_active?: boolean | null
          nome?: string
          telefone?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      invoices_summary: {
        Row: {
          competence: string | null
          created_at: string | null
          creditor_cnpj: string | null
          creditor_name: string | null
          id: string | null
          invoice_number: string | null
          observation: string | null
          owner: string | null
          request_number: string | null
          species: Database["public"]["Enums"]["invoice_species"] | null
          status: Database["public"]["Enums"]["invoice_status"] | null
          updated_at: string | null
          value: number | null
        }
        Insert: {
          competence?: string | null
          created_at?: string | null
          creditor_cnpj?: string | null
          creditor_name?: string | null
          id?: string | null
          invoice_number?: string | null
          observation?: string | null
          owner?: string | null
          request_number?: string | null
          species?: Database["public"]["Enums"]["invoice_species"] | null
          status?: Database["public"]["Enums"]["invoice_status"] | null
          updated_at?: string | null
          value?: number | null
        }
        Update: {
          competence?: string | null
          created_at?: string | null
          creditor_cnpj?: string | null
          creditor_name?: string | null
          id?: string | null
          invoice_number?: string | null
          observation?: string | null
          owner?: string | null
          request_number?: string | null
          species?: Database["public"]["Enums"]["invoice_species"] | null
          status?: Database["public"]["Enums"]["invoice_status"] | null
          updated_at?: string | null
          value?: number | null
        }
        Relationships: []
      }
    }
    Functions: {
      get_current_user_project_id: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_user_profile: {
        Args: { user_id: string }
        Returns: {
          id: string
          email: string
          nome: string
          telefone: string
          cargo: string
          foto: string
          is_active: boolean
        }[]
      }
      has_role: {
        Args: {
          _user_id: string
          _role: Database["public"]["Enums"]["user_role"]
        }
        Returns: boolean
      }
      same_company: {
        Args: { _user_id: string; _target_user_id: string }
        Returns: boolean
      }
      update_user_profile: {
        Args: { user_id: string; profile_data: Json }
        Returns: undefined
      }
      user_belongs_to_project: {
        Args: { _project_id: string }
        Returns: boolean
      }
    }
    Enums: {
      certificate_status: "AUSENTE" | "VENCIDA" | "A VENCER" | "VÁLIDA"
      invoice_species: "NCI" | "ND" | "MAT_MED" | "NRT" | "NST"
      invoice_status:
        | "pendente"
        | "analise"
        | "aprovada"
        | "nao-aprovada"
        | "corrigida"
        | "paga"
      user_role:
        | "super_admin"
        | "gerente_prestacao"
        | "analista_prestacao"
        | "analista_pagamento"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      certificate_status: ["AUSENTE", "VENCIDA", "A VENCER", "VÁLIDA"],
      invoice_species: ["NCI", "ND", "MAT_MED", "NRT", "NST"],
      invoice_status: [
        "pendente",
        "analise",
        "aprovada",
        "nao-aprovada",
        "corrigida",
        "paga",
      ],
      user_role: [
        "super_admin",
        "gerente_prestacao",
        "analista_prestacao",
        "analista_pagamento",
      ],
    },
  },
} as const
