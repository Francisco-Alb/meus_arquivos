
import { useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const NotFound = () => {
  const location = useLocation();
  const isCustomRoute = location.pathname !== "/404";

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="text-center">
        {isCustomRoute ? (
          <>
            <h1 className="text-4xl font-bold mb-4">Em Desenvolvimento</h1>
            <p className="text-xl text-gray-600 mb-6">
              Esta página está em desenvolvimento e será implementada em breve.
            </p>
          </>
        ) : (
          <>
            <h1 className="text-4xl font-bold mb-4">404</h1>
            <p className="text-xl text-gray-600 mb-6">
              Página não encontrada
            </p>
          </>
        )}
        <Button asChild>
          <Link to="/">Voltar para o Dashboard</Link>
        </Button>
      </div>
    </div>
  );
};

export default NotFound;
