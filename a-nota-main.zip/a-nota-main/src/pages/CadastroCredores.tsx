import { useState } from "react";
import { Building, Edit, Trash2, X, Check, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import AppLayout from "@/components/layout/AppLayout";
import { useSupabaseCredores } from "@/hooks/useSupabaseCredores";
import { useSupabaseInvoices } from "@/hooks/useSupabaseInvoices";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";

const CadastroCredores = () => {
  const { credores, loading, addCredor, editCredor, deleteCredor } = useSupabaseCredores();
  const { invoices } = useSupabaseInvoices();
  
  const [nomeCredor, setNomeCredor] = useState("");
  const [cnpjCredor, setCnpjCredor] = useState("");
  
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingCredor, setEditingCredor] = useState<any>(null);
  const [deletingCredorId, setDeletingCredorId] = useState<string | null>(null);
  const [editNomeCredor, setEditNomeCredor] = useState("");
  const [editCnpjCredor, setEditCnpjCredor] = useState("");

  const [searchTerm, setSearchTerm] = useState("");

  const filteredCredores = credores.filter(credor =>
    credor.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    credor.cnpj.includes(searchTerm)
  );

  const formatarCNPJ = (valor: string) => {
    const apenasNumeros = valor.replace(/\D/g, '');
    
    let cnpjFormatado = apenasNumeros;
    if (apenasNumeros.length > 2) {
      cnpjFormatado = `${apenasNumeros.substring(0, 2)}.${apenasNumeros.substring(2)}`;
    }
    if (apenasNumeros.length > 5) {
      cnpjFormatado = `${cnpjFormatado.substring(0, 6)}.${cnpjFormatado.substring(6)}`;
    }
    if (apenasNumeros.length > 8) {
      cnpjFormatado = `${cnpjFormatado.substring(0, 10)}/`;
      cnpjFormatado += apenasNumeros.substring(8, 12);
    }
    if (apenasNumeros.length > 12) {
      cnpjFormatado = `${cnpjFormatado.substring(0, 15)}-${apenasNumeros.substring(12, 14)}`;
    }
    
    return cnpjFormatado;
  };

  const handleCnpjCredorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const valorFormatado = formatarCNPJ(e.target.value);
    setCnpjCredor(valorFormatado);
  };

  const handleEditCnpjChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const valorFormatado = formatarCNPJ(e.target.value);
    setEditCnpjCredor(valorFormatado);
  };

  const cadastrarCredor = async () => {
    if (!nomeCredor || !cnpjCredor) {
      toast.error("Preencha todos os campos do cadastro de credor");
      return;
    }
    
    if (cnpjCredor.replace(/\D/g, '').length !== 14) {
      toast.error("CNPJ inválido. Deve conter 14 dígitos.");
      return;
    }
    
    if (credores.some(c => c.cnpj === cnpjCredor)) {
      toast.error("CNPJ já cadastrado");
      return;
    }
    
    const success = await addCredor({
      nome: nomeCredor,
      cnpj: cnpjCredor
    });
    
    if (success) {
      setNomeCredor("");
      setCnpjCredor("");
      
      // Disparar evento para notificar outras páginas
      document.dispatchEvent(new CustomEvent('creditorAdded'));
    }
  };

  const handleEditCredor = (credor: any) => {
    setEditingCredor(credor);
    setEditNomeCredor(credor.nome);
    setEditCnpjCredor(credor.cnpj);
    setIsEditDialogOpen(true);
  };

  const saveEditedCredor = async () => {
    if (!editingCredor) return;
    if (!editNomeCredor || !editCnpjCredor) {
      toast.error("Preencha todos os campos");
      return;
    }
    
    if (editCnpjCredor.replace(/\D/g, '').length !== 14) {
      toast.error("CNPJ inválido. Deve conter 14 dígitos.");
      return;
    }
    
    const existingWithCnpj = credores.find(c => c.cnpj === editCnpjCredor && c.id !== editingCredor.id);
    if (existingWithCnpj) {
      toast.error("CNPJ já cadastrado para outro credor");
      return;
    }
    
    const success = await editCredor(editingCredor.id, {
      nome: editNomeCredor,
      cnpj: editCnpjCredor
    });
    
    if (success) {
      setIsEditDialogOpen(false);
    }
  };

  const handleDeleteCredor = (id: string) => {
    setDeletingCredorId(id);
    setIsDeleteDialogOpen(true);
  };

  const confirmDeleteCredor = async () => {
    if (deletingCredorId === null) return;
    
    const credor = credores.find(c => c.id === deletingCredorId);
    
    if (credor) {
      const hasRelatedInvoices = invoices.some(invoice => invoice.creditor_name === credor.nome);
      
      if (hasRelatedInvoices) {
        toast.error("Este credor possui notas fiscais cadastradas e não pode ser excluído");
        setIsDeleteDialogOpen(false);
        setDeletingCredorId(null);
        return;
      }
      
      const success = await deleteCredor(deletingCredorId);
      
      if (success) {
        setIsDeleteDialogOpen(false);
        setDeletingCredorId(null);
        
        // Disparar evento para notificar outras páginas
        document.dispatchEvent(new CustomEvent('creditorRemoved'));
      }
    }
  };

  if (loading) {
    return (
      <AppLayout activePath="/cadastro-credores">
        <div className="p-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-lg">Carregando...</div>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout activePath="/cadastro-credores">
      <div className="p-6 space-y-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Cadastro de Credores</h1>

        <Card>
          <CardHeader className="bg-gray-50 border-b">
            <div className="flex items-center">
              <Building size={24} className="mr-2 text-sidebar" />
              <CardTitle className="text-xl">Cadastro de Credor</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="nomeCredor" className="text-sm font-medium">
                  Credor
                </label>
                <Input
                  id="nomeCredor"
                  value={nomeCredor}
                  onChange={(e) => setNomeCredor(e.target.value)}
                  placeholder="Nome do Credor"
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="cnpjCredor" className="text-sm font-medium">
                  CNPJ do Credor
                </label>
                <Input
                  id="cnpjCredor"
                  value={cnpjCredor}
                  onChange={handleCnpjCredorChange}
                  placeholder="00.000.000/0000-00"
                  maxLength={18}
                />
              </div>
            </div>
            
            <div className="flex justify-end mt-4">
              <Button onClick={cadastrarCredor} className="bg-sidebar hover:bg-sidebar-accent">
                Cadastrar
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="bg-gray-50 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Building size={24} className="mr-2 text-sidebar" />
                <CardTitle className="text-xl">Credores Cadastrados</CardTitle>
              </div>
              <div className="relative w-full max-w-sm">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Pesquisar credores..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>CNPJ</TableHead>
                    <TableHead className="w-[100px] text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCredores.map((credor) => (
                    <TableRow key={credor.id}>
                      <TableCell>{credor.nome}</TableCell>
                      <TableCell>{credor.cnpj}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => handleEditCredor(credor)}
                        >
                          <Edit size={16} />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => handleDeleteCredor(credor.id)}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {filteredCredores.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center py-8 text-muted-foreground">
                        {searchTerm ? "Nenhum credor encontrado para sua busca" : "Nenhum credor cadastrado"}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
        
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar Credor</DialogTitle>
              <DialogDescription>
                Faça as alterações necessárias nos dados do credor.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label htmlFor="editNome" className="text-sm font-medium">
                  Nome do Credor
                </label>
                <Input
                  id="editNome"
                  value={editNomeCredor}
                  onChange={(e) => setEditNomeCredor(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="editCnpj" className="text-sm font-medium">
                  CNPJ
                </label>
                <Input
                  id="editCnpj"
                  value={editCnpjCredor}
                  onChange={handleEditCnpjChange}
                  maxLength={18}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                <X size={16} className="mr-1" /> Cancelar
              </Button>
              <Button onClick={saveEditedCredor}>
                <Check size={16} className="mr-1" /> Salvar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirmar Exclusão</DialogTitle>
              <DialogDescription>
                Tem certeza que deseja excluir este credor? Esta ação não pode ser desfeita.
              </DialogDescription>
            </DialogHeader>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                <X size={16} className="mr-1" /> Cancelar
              </Button>
              <Button variant="destructive" onClick={confirmDeleteCredor}>
                <Trash2 size={16} className="mr-1" /> Excluir
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
};

export default CadastroCredores;
