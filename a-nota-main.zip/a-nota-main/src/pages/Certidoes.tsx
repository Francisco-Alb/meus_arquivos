
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import AppLayout from "@/components/layout/AppLayout";
import { Download } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { Label } from "@/components/ui/label";
import { format, addDays, isBefore, parseISO } from "date-fns";
import { useSupabaseCertificates } from "@/hooks/useSupabaseCertificates";
import { useSupabaseCredores } from "@/hooks/useSupabaseCredores";
import { useFileUpload } from "@/hooks/useFileUpload";
import { joinCertificatesPDF, downloadPDF } from "@/utils/pdfUtils";

// Function to calculate document status based on expiration date
const calculateStatus = (expirationDate: string | null): string => {
  if (!expirationDate) return "AUSENTE";
  
  try {
    const date = typeof expirationDate === 'string' ? parseISO(expirationDate) : expirationDate;
    const today = new Date();
    const tenDaysFromNow = addDays(today, 10);
    
    if (isBefore(date, today)) return "VENCIDA";
    if (isBefore(date, tenDaysFromNow)) return "A VENCER";
    return "VÁLIDA";
  } catch (error) {
    console.error("Error parsing date:", error);
    return "VENCIDA";
  }
};

const Certidoes = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedFilter, setSelectedFilter] = useState<string | null>(null);
  const { certificates, loading, updateCertificate, refetch } = useSupabaseCertificates();
  const { credores, refetch: refetchCredores } = useSupabaseCredores();
  const { uploadFile, downloadFile, uploading } = useFileUpload();
  
  // Document update dialog
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<{
    certidaoId: string;
    type: string;
    currentDate: string | null;
  } | null>(null);
  const [newExpirationDate, setNewExpirationDate] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Atualizar lista quando credores mudam - usando useEffect para detectar mudanças
  useEffect(() => {
    console.log('Credores mudaram, atualizando certificados...');
    refetch();
  }, [credores.length, refetch]);

  // Monitorar quando novos credores são adicionados
  useEffect(() => {
    const handleCreditorAdded = () => {
      console.log('Evento creditorAdded detectado, atualizando listas...');
      refetchCredores();
      refetch();
    };

    const handleCreditorRemoved = () => {
      console.log('Evento creditorRemoved detectado, atualizando listas...');
      refetchCredores();
      refetch();
    };

    document.addEventListener('creditorAdded', handleCreditorAdded);
    document.addEventListener('creditorRemoved', handleCreditorRemoved);

    return () => {
      document.removeEventListener('creditorAdded', handleCreditorAdded);
      document.removeEventListener('creditorRemoved', handleCreditorRemoved);
    };
  }, [refetch, refetchCredores]);

  // Filter certificates based on search term and selected filter
  const filteredCertidoes = certificates.filter((certidao) => {
    const matchesSearch = certidao.creditor_name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         certidao.creditor_cnpj.includes(searchTerm);
    
    if (!selectedFilter) return matchesSearch;
    
    return matchesSearch && (
      certidao.municipal_status === selectedFilter ||
      certidao.estadual_status === selectedFilter ||
      certidao.federal_status === selectedFilter ||
      certidao.trabalhista_status === selectedFilter ||
      certidao.fgts_status === selectedFilter
    );
  });

  // Open document update dialog
  const handleDocumentClick = (certidaoId: string, type: string, currentDate: string | null) => {
    console.log('=== ABRINDO DIALOG DE UPLOAD ===');
    console.log('Dados do documento:', { certidaoId, type, currentDate });
    setSelectedDocument({ certidaoId, type, currentDate });
    setNewExpirationDate(currentDate || "");
    setSelectedFile(null);
    setDialogOpen(true);
  };

  // Handle file selection
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    console.log('=== ARQUIVO SELECIONADO ===');
    console.log('Arquivo:', { nome: file.name, tipo: file.type, tamanho: file.size });
    
    if (file.type !== 'application/pdf') {
      toast.error("Apenas arquivos PDF são permitidos.");
      e.target.value = '';
      return;
    }
    
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Arquivo muito grande. Limite de 10MB.");
      e.target.value = '';
      return;
    }
    
    setSelectedFile(file);
    toast.success(`Arquivo "${file.name}" selecionado`);
  };

  // Handle document update submission
  const handleUpdateDocument = async () => {
    if (!selectedDocument || !selectedFile || !newExpirationDate) {
      toast.error("Por favor, selecione um arquivo e defina a data de validade.");
      return;
    }

    console.log('=== INICIANDO PROCESSO DE ATUALIZAÇÃO ===');
    console.log('Documento selecionado:', selectedDocument);
    console.log('Arquivo selecionado:', selectedFile.name);
    console.log('Data de validade:', newExpirationDate);
    
    try {
      // Upload do arquivo
      console.log('Iniciando upload do arquivo...');
      const filePath = await uploadFile(selectedFile, selectedDocument.certidaoId, selectedDocument.type);
      
      if (!filePath) {
        console.error('Upload falhou - sem caminho retornado');
        toast.error("Falha no upload do arquivo. Tente novamente.");
        return;
      }

      console.log('Upload concluído, atualizando banco de dados...');
      console.log('Caminho do arquivo:', filePath);

      // Calcular status e preparar dados de atualização
      const docType = selectedDocument.type.toLowerCase();
      const status = calculateStatus(newExpirationDate);
      
      const updateData: any = {};
      updateData[`${docType}_date`] = newExpirationDate;
      updateData[`${docType}_status`] = status;
      updateData[`${docType}_file_path`] = filePath;

      console.log('Dados para atualização:', updateData);

      // Atualizar certificado no banco
      const success = await updateCertificate(selectedDocument.certidaoId, updateData);

      if (success) {
        console.log('=== ATUALIZAÇÃO CONCLUÍDA COM SUCESSO ===');
        toast.success(`Certidão ${selectedDocument.type.toUpperCase()} atualizada com sucesso!`);
        setDialogOpen(false);
        setSelectedDocument(null);
        setSelectedFile(null);
        setNewExpirationDate("");
        refetch();
      } else {
        console.error('Falha na atualização do banco de dados');
        toast.error("Erro ao atualizar no banco de dados.");
      }
    } catch (error) {
      console.error('=== ERRO NO PROCESSO DE ATUALIZAÇÃO ===');
      console.error('Erro completo:', error);
      toast.error("Erro inesperado durante a atualização.");
    }
  };

  // Generate status date cell - REMOVIDO O ÍCONE DE UPLOAD
  const renderStatusDateCell = (
    certidaoId: string, 
    type: string, 
    dateInfo: { date: string | null; status: string; filePath?: string | null; }
  ) => {
    const statusColors: Record<string, string> = {
      'AUSENTE': 'bg-purple-500',
      'VENCIDA': 'bg-red-500',
      'A VENCER': 'bg-orange-500',
      'VÁLIDA': 'bg-green-500',
    };
    
    // Texto a ser exibido
    const displayText = dateInfo.date ? format(new Date(dateInfo.date), 'dd/MM/yyyy') : 'AUSENTE';
    
    return (
      <TableCell 
        className={`${statusColors[dateInfo.status]} text-white py-3 text-center cursor-pointer hover:opacity-80 transition-opacity`}
        onClick={() => handleDocumentClick(certidaoId, type, dateInfo.date)}
      >
        <div className="flex items-center justify-center">
          <span>{displayText}</span>
        </div>
      </TableCell>
    );
  };

  // Handle joining certificates for a creditor
  const handleJoinCreditorCertificates = async (creditorName: string, creditorCnpj: string) => {
    try {
      console.log('Starting certificate join process for:', creditorName);
      
      const creditor = certificates.find(
        cert => cert.creditor_name === creditorName && cert.creditor_cnpj === creditorCnpj
      );

      if (!creditor) {
        toast.error("Certidões do credor não encontradas.");
        return;
      }

      // Prepare certificate data
      const certificateFiles = [
        {
          type: "FGTS",
          filePath: creditor.fgts_file_path,
          date: creditor.fgts_date
        },
        {
          type: "Municipal",
          filePath: creditor.municipal_file_path,
          date: creditor.municipal_date
        },
        {
          type: "Estadual",
          filePath: creditor.estadual_file_path,
          date: creditor.estadual_date
        },
        {
          type: "Federal",
          filePath: creditor.federal_file_path,
          date: creditor.federal_date
        },
        {
          type: "Trabalhista",
          filePath: creditor.trabalhista_file_path,
          date: creditor.trabalhista_date
        }
      ];

      const availableCerts = certificateFiles.filter(cert => cert.filePath);
      
      if (availableCerts.length === 0) {
        toast.error("Nenhuma certidão disponível para este credor.");
        return;
      }

      toast.info(`Juntando ${availableCerts.length} certidão(ões)... Aguarde.`);

      // Generate joined PDF using real files from Supabase Storage
      const pdfBlob = await joinCertificatesPDF(creditorName, certificateFiles, downloadFile);
      
      // Download the file
      const filename = `CND_${creditorName.replace(/\s+/g, '_')}_${creditorCnpj}_${new Date().toISOString().split('T')[0]}.pdf`;
      downloadPDF(pdfBlob, filename);

      toast.success(`CNDs de ${creditorName} juntadas e baixadas com sucesso!`);
      
    } catch (error) {
      console.error('Error joining certificates:', error);
      toast.error("Erro ao gerar o arquivo PDF das certidões.");
    }
  };

  if (loading) {
    return (
      <AppLayout activePath="/certidoes">
        <div className="p-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-lg">Carregando certidões...</div>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout activePath="/certidoes">
      <div className="p-6 space-y-6">
        {/* Certificates List Section */}
        <Card className="shadow-md">
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <CardTitle className="text-xl">Lista de Certidões</CardTitle>
              <div className="flex items-center gap-2">
                <Label htmlFor="search" className="text-sm font-medium">Pesquisar:</Label>
                <Input 
                  id="search"
                  placeholder="Credor/CNPJ" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-64"
                />
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-4">
              <Label className="text-sm font-medium mr-2">Filtrar:</Label>
              <div className="flex flex-wrap gap-2">
                <Button 
                  onClick={() => setSelectedFilter(selectedFilter === "AUSENTE" ? null : "AUSENTE")}
                  variant="outline"
                  size="sm"
                  className={`${selectedFilter === "AUSENTE" ? "bg-purple-500 text-white" : ""}`}
                >
                  AUSENTE
                </Button>
                <Button 
                  onClick={() => setSelectedFilter(selectedFilter === "VENCIDA" ? null : "VENCIDA")}
                  variant="outline"
                  size="sm"
                  className={`${selectedFilter === "VENCIDA" ? "bg-red-500 text-white" : ""}`}
                >
                  VENCIDA
                </Button>
                <Button 
                  onClick={() => setSelectedFilter(selectedFilter === "A VENCER" ? null : "A VENCER")}
                  variant="outline"
                  size="sm"
                  className={`${selectedFilter === "A VENCER" ? "bg-orange-500 text-white" : ""}`}
                >
                  A VENCER
                </Button>
                <Button 
                  onClick={() => setSelectedFilter(selectedFilter === "VÁLIDA" ? null : "VÁLIDA")}
                  variant="outline"
                  size="sm"
                  className={`${selectedFilter === "VÁLIDA" ? "bg-green-500 text-white" : ""}`}
                >
                  VÁLIDA
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="font-semibold">Credor</TableHead>
                    <TableHead className="font-semibold">CNPJ</TableHead>
                    <TableHead className="text-center font-semibold">FGTS</TableHead>
                    <TableHead className="text-center font-semibold">Municipal</TableHead>
                    <TableHead className="text-center font-semibold">Estadual</TableHead>
                    <TableHead className="text-center font-semibold">Federal</TableHead>
                    <TableHead className="text-center font-semibold">Trabalhista</TableHead>
                    <TableHead className="text-center font-semibold">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCertidoes.map((certidao) => (
                    <TableRow key={certidao.id} className="hover:bg-muted/30">
                      <TableCell className="font-medium">{certidao.creditor_name}</TableCell>
                      <TableCell>{certidao.creditor_cnpj}</TableCell>
                      {renderStatusDateCell(certidao.id, "fgts", {
                        date: certidao.fgts_date,
                        status: certidao.fgts_status || "AUSENTE",
                        filePath: certidao.fgts_file_path
                      })}
                      {renderStatusDateCell(certidao.id, "municipal", {
                        date: certidao.municipal_date,
                        status: certidao.municipal_status || "AUSENTE",
                        filePath: certidao.municipal_file_path
                      })}
                      {renderStatusDateCell(certidao.id, "estadual", {
                        date: certidao.estadual_date,
                        status: certidao.estadual_status || "AUSENTE",
                        filePath: certidao.estadual_file_path
                      })}
                      {renderStatusDateCell(certidao.id, "federal", {
                        date: certidao.federal_date,
                        status: certidao.federal_status || "AUSENTE",
                        filePath: certidao.federal_file_path
                      })}
                      {renderStatusDateCell(certidao.id, "trabalhista", {
                        date: certidao.trabalhista_date,
                        status: certidao.trabalhista_status || "AUSENTE",
                        filePath: certidao.trabalhista_file_path
                      })}
                      <TableCell className="text-center">
                        <Button 
                          size="sm"
                          className="bg-sidebar text-white hover:bg-sidebar/90"
                          onClick={() => handleJoinCreditorCertificates(certidao.creditor_name, certidao.creditor_cnpj)}
                        >
                          <Download className="mr-1" size={14} />
                          Juntar
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {filteredCertidoes.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                        {searchTerm || selectedFilter ? 
                          "Nenhuma certidão encontrada para os filtros aplicados." : 
                          "Nenhuma certidão cadastrada."
                        }
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
            <p className="text-sm text-right mt-4 text-gray-500 italic">
              Clique nas células coloridas para fazer upload das certidões em PDF.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Document Update Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Upload - Certidão {selectedDocument?.type?.toUpperCase()}</DialogTitle>
            <DialogDescription>
              Faça o upload da certidão em PDF e defina a data de validade.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="expiration-date" className="text-right col-span-1">
                Validade
              </Label>
              <Input
                id="expiration-date"
                type="date"
                value={newExpirationDate}
                onChange={(e) => setNewExpirationDate(e.target.value)}
                className="col-span-3"
                required
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="document-file" className="text-right col-span-1">
                Arquivo PDF
              </Label>
              <div className="col-span-3">
                <Input
                  id="document-file"
                  type="file"
                  accept=".pdf"
                  onChange={handleFileSelect}
                  className="col-span-3"
                  required
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Somente arquivos PDF. Limite: 10MB.
                </p>
                {selectedFile && (
                  <p className="text-xs text-green-600 mt-1 font-medium">
                    ✓ {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                  </p>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setDialogOpen(false);
              setSelectedDocument(null);
              setSelectedFile(null);
              setNewExpirationDate("");
            }}>
              Cancelar
            </Button>
            <Button 
              onClick={handleUpdateDocument} 
              className="bg-sidebar hover:bg-sidebar/90"
              disabled={uploading || !selectedFile || !newExpirationDate}
            >
              {uploading ? "Enviando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
};

export default Certidoes;
