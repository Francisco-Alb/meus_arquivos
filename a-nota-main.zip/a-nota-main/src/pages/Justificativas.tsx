
import { useState } from "react";
import { MessageSquare, Plus, Edit, Trash2, X, Check } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import AppLayout from "@/components/layout/AppLayout";
import { useSupabaseJustifications } from "@/hooks/useSupabaseJustifications";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";

const Justificativas = () => {
  const { justifications, loading, addJustification, updateJustification, deleteJustification } = useSupabaseJustifications();
  
  const [novaJustificativa, setNovaJustificativa] = useState("");
  
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingJustification, setEditingJustification] = useState<any>(null);
  const [deletingJustificationId, setDeletingJustificationId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");

  const adicionarJustificativa = async () => {
    if (!novaJustificativa.trim()) {
      toast.error("Digite uma justificativa válida");
      return;
    }
    
    const success = await addJustification({ text: novaJustificativa.trim() });
    
    if (success) {
      setNovaJustificativa("");
    }
  };

  const handleEditJustification = (justification: any) => {
    setEditingJustification(justification);
    setEditText(justification.text);
    setIsEditDialogOpen(true);
  };

  const saveEditedJustification = async () => {
    if (!editingJustification) return;
    if (!editText.trim()) {
      toast.error("Digite uma justificativa válida");
      return;
    }
    
    const success = await updateJustification(editingJustification.id, {
      text: editText.trim()
    });
    
    if (success) {
      setIsEditDialogOpen(false);
    }
  };

  const handleDeleteJustification = (id: string) => {
    setDeletingJustificationId(id);
    setIsDeleteDialogOpen(true);
  };

  const confirmDeleteJustification = async () => {
    if (deletingJustificationId === null) return;
    
    const success = await deleteJustification(deletingJustificationId);
    
    if (success) {
      setIsDeleteDialogOpen(false);
      setDeletingJustificationId(null);
    }
  };

  if (loading) {
    return (
      <AppLayout activePath="/justificativas">
        <div className="p-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-lg">Carregando...</div>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout activePath="/justificativas">
      <div className="p-6 space-y-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Gerenciar Justificativas</h1>

        <Card>
          <CardHeader className="bg-gray-50 border-b">
            <div className="flex items-center">
              <MessageSquare size={24} className="mr-2 text-sidebar" />
              <CardTitle className="text-xl">Adicionar Nova Justificativa</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="flex gap-2">
              <Input
                value={novaJustificativa}
                onChange={(e) => setNovaJustificativa(e.target.value)}
                placeholder="Digite a nova justificativa..."
                onKeyPress={(e) => e.key === 'Enter' && adicionarJustificativa()}
              />
              <Button onClick={adicionarJustificativa} className="bg-sidebar hover:bg-sidebar-accent flex items-center gap-1">
                <Plus size={16} />
                Adicionar
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="bg-gray-50 border-b">
            <div className="flex items-center">
              <MessageSquare size={24} className="mr-2 text-sidebar" />
              <CardTitle className="text-xl">Justificativas Cadastradas</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Justificativa</TableHead>
                    <TableHead className="w-[150px] text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {justifications.map((justificativa) => (
                    <TableRow key={justificativa.id}>
                      <TableCell>{justificativa.text}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => handleEditJustification(justificativa)}
                        >
                          <Edit size={16} />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => handleDeleteJustification(justificativa.id)}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {justifications.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={2} className="text-center py-8 text-muted-foreground">
                        Nenhuma justificativa cadastrada
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
        
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar Justificativa</DialogTitle>
              <DialogDescription>
                Faça as alterações necessárias na justificativa.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <Input
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                placeholder="Digite a justificativa..."
              />
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                <X size={16} className="mr-1" /> Cancelar
              </Button>
              <Button onClick={saveEditedJustification}>
                <Check size={16} className="mr-1" /> Salvar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirmar Exclusão</DialogTitle>
              <DialogDescription>
                Tem certeza que deseja excluir esta justificativa? Esta ação não pode ser desfeita.
              </DialogDescription>
            </DialogHeader>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                <X size={16} className="mr-1" /> Cancelar
              </Button>
              <Button variant="destructive" onClick={confirmDeleteJustification}>
                <Trash2 size={16} className="mr-1" /> Excluir
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
};

export default Justificativas;
