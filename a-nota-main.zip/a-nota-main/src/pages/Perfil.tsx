
import React, { useState, useEffect } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Camera, Save, User, Users } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import CadastroAnalistas from "@/components/users/CadastroAnalistas";

const Perfil = () => {
  const { toast } = useToast();
  const { userProfile, updateProfile } = useAuth();
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    telefone: "",
    senha: "",
    confirmarSenha: "",
    foto: ""
  });

  // Inicializar formData com dados do perfil
  useEffect(() => {
    if (userProfile) {
      setFormData({
        nome: userProfile.nome,
        email: userProfile.email,
        telefone: userProfile.telefone || "",
        senha: "",
        confirmarSenha: "",
        foto: userProfile.foto || ""
      });
    }
  }, [userProfile]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    if (formData.senha && formData.senha !== formData.confirmarSenha) {
      toast({
        title: "Erro",
        description: "As senhas não coincidem",
        variant: "destructive"
      });
      return;
    }

    const { error } = await updateProfile({
      nome: formData.nome,
      telefone: formData.telefone,
      foto: formData.foto
    });

    if (error) {
      toast({
        title: "Erro",
        description: "Erro ao atualizar perfil",
        variant: "destructive"
      });
    } else {
      toast({
        title: "Sucesso",
        description: "Perfil atualizado com sucesso"
      });

      // Limpar campos de senha após salvar
      setFormData(prev => ({
        ...prev,
        senha: "",
        confirmarSenha: ""
      }));
    }
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setFormData(prev => ({
          ...prev,
          foto: result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const isGerente = userProfile?.cargo === 'gerente_prestacao_contas';

  return (
    <AppLayout activePath="/perfil">
      <div className="container mx-auto p-6 max-w-6xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Perfil do Usuário</h1>
          <p className="text-gray-600">Gerencie suas informações pessoais e configurações</p>
        </div>

        <Tabs defaultValue="perfil" className="space-y-6">
          <TabsList>
            <TabsTrigger value="perfil" className="flex items-center gap-2">
              <User size={16} />
              Meu Perfil
            </TabsTrigger>
            {isGerente && (
              <TabsTrigger value="usuarios" className="flex items-center gap-2">
                <Users size={16} />
                Gerenciar Usuários
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="perfil" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Seção do Avatar e Cargo */}
              <Card className="lg:col-span-1">
                <CardHeader>
                  <CardTitle>Foto e Cargo</CardTitle>
                  <CardDescription>Sua foto de perfil e informações do cargo</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-col items-center space-y-4">
                    <div className="relative">
                      <Avatar className="w-32 h-32">
                        <AvatarImage src={formData.foto} />
                        <AvatarFallback className="text-2xl">
                          {userProfile ? getInitials(userProfile.nome) : <User size={48} />}
                        </AvatarFallback>
                      </Avatar>
                      <label htmlFor="photo-upload" className="absolute bottom-0 right-0 bg-primary text-white p-2 rounded-full cursor-pointer hover:bg-primary/90 transition-colors">
                        <Camera size={16} />
                      </label>
                      <input
                        id="photo-upload"
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="hidden"
                      />
                    </div>
                    
                    <div className="text-center">
                      <h3 className="font-semibold text-lg">{formData.nome}</h3>
                      <Badge variant="secondary" className="mt-2">
                        {userProfile?.cargo === 'gerente_prestacao_contas' ? 'Gerente de Prestação de Contas' :
                         userProfile?.cargo === 'analista_prestacao_contas' ? 'Analista de Prestação de Contas' :
                         'Analista de Pagamento'}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Seção de Informações Pessoais */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Informações Pessoais</CardTitle>
                  <CardDescription>Atualize suas informações de contato e credenciais</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="nome">Nome Completo</Label>
                      <Input
                        id="nome"
                        value={formData.nome}
                        onChange={(e) => handleInputChange("nome", e.target.value)}
                        placeholder="Digite seu nome completo"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        disabled
                        className="bg-gray-100"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="telefone">Telefone</Label>
                    <Input
                      id="telefone"
                      value={formData.telefone}
                      onChange={(e) => handleInputChange("telefone", e.target.value)}
                      placeholder="Digite seu telefone"
                    />
                  </div>

                  <div className="border-t pt-6">
                    <h4 className="font-semibold mb-4 text-gray-900">Alterar Senha</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="senha">Nova Senha</Label>
                        <Input
                          id="senha"
                          type="password"
                          value={formData.senha}
                          onChange={(e) => handleInputChange("senha", e.target.value)}
                          placeholder="Digite a nova senha"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="confirmarSenha">Confirmar Nova Senha</Label>
                        <Input
                          id="confirmarSenha"
                          type="password"
                          value={formData.confirmarSenha}
                          onChange={(e) => handleInputChange("confirmarSenha", e.target.value)}
                          placeholder="Confirme a nova senha"
                        />
                      </div>
                    </div>
                    <p className="text-sm text-gray-500 mt-2">
                      Deixe em branco se não quiser alterar a senha
                    </p>
                  </div>

                  <div className="flex justify-end pt-4">
                    <Button onClick={handleSave} className="flex items-center gap-2">
                      <Save size={16} />
                      Salvar Alterações
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {isGerente && (
            <TabsContent value="usuarios">
              <CadastroAnalistas />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default Perfil;
