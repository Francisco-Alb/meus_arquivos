
import React, { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Download, TrendingUp, Clock, FileText } from "lucide-react";

const RelatorioEvolucao = () => {
  const [periodo, setPeriodo] = useState<string | undefined>(undefined);

  const handleGerarRelatorio = () => {
    if (!periodo) {
      console.warn("Por favor, selecione um período para gerar o relatório.");
      alert("Por favor, selecione um período para gerar o relatório.");
      return;
    }
    console.log(`Gerando relatório para o período: ${periodo}`);
    alert(`Relatório para o período "${periodo}" será gerado aqui (funcionalidade de PDF pendente).`);
  };

  return (
    <AppLayout activePath="/exportar">
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Header Section */}
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                <TrendingUp size={32} />
              </div>
            </div>
            <h1 className="text-3xl font-bold text-gray-900">Relatório de Evolução</h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Acompanhe métricas detalhadas sobre o processo de aprovação de notas fiscais, 
              incluindo tempo de permanência em cada status, ranking de justificativas e evolução geral do sistema.
            </p>
          </div>

          {/* Main Card */}
          <Card className="shadow-xl border-0 bg-white/70 backdrop-blur-sm">
            <CardHeader className="space-y-4 pb-8">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                  <FileText size={24} />
                </div>
                <div>
                  <CardTitle className="text-xl text-gray-900">Gerar Relatório Analítico</CardTitle>
                  <CardDescription className="text-gray-600 mt-1">
                    Selecione o período para análise detalhada das métricas de notas fiscais
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-8">
              {/* Info Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-6 rounded-xl bg-gradient-to-r from-blue-50 to-blue-100 border border-blue-200">
                  <div className="flex items-start gap-4">
                    <Clock className="text-blue-600 mt-1" size={24} />
                    <div>
                      <p className="text-lg font-semibold text-blue-700 mb-2">Tempo de Análise</p>
                      <p className="text-sm text-blue-600 leading-relaxed">
                        Mede o período em que determinado número de notas permaneceu em cada status do processo de aprovação.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="p-6 rounded-xl bg-gradient-to-r from-purple-50 to-purple-100 border border-purple-200">
                  <div className="flex items-start gap-4">
                    <FileText className="text-purple-600 mt-1" size={24} />
                    <div>
                      <p className="text-lg font-semibold text-purple-700 mb-2">Justificativas</p>
                      <p className="text-sm text-purple-600 leading-relaxed">
                        Ranking das principais justificativas utilizadas para rejeição ou correção de notas em determinado período.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="p-6 rounded-xl bg-gradient-to-r from-green-50 to-green-100 border border-green-200">
                  <div className="flex items-start gap-4">
                    <TrendingUp className="text-green-600 mt-1" size={24} />
                    <div>
                      <p className="text-lg font-semibold text-green-700 mb-2">Evolução</p>
                      <p className="text-sm text-green-600 leading-relaxed">
                        Relatório geral macro da evolução das notas fiscais, mostrando tendências e padrões do processo.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Period Selection */}
              <div className="space-y-4">
                <label htmlFor="periodo-select" className="block text-sm font-semibold text-gray-700">
                  Período do Relatório
                </label>
                <Select value={periodo} onValueChange={setPeriodo}>
                  <SelectTrigger id="periodo-select" className="w-full h-12 bg-white border-gray-200 focus:border-blue-500 focus:ring-blue-500">
                    <SelectValue placeholder="Selecione o período de análise" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-gray-200 shadow-lg">
                    <SelectItem value="mensal" className="hover:bg-blue-50">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                        <span>Relatório Mensal</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="semestral" className="hover:bg-purple-50">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                        <span>Relatório Semestral</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="anual" className="hover:bg-green-50">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-green-500"></div>
                        <span>Relatório Anual</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Generate Button */}
              <Button 
                onClick={handleGerarRelatorio} 
                className="w-full h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
                disabled={!periodo}
              >
                <Download className="mr-3 h-5 w-5" />
                Gerar e Baixar Relatório (PDF)
              </Button>
              
              <div className="text-center">
                <p className="text-xs text-gray-500 bg-gray-50 rounded-lg p-3 inline-block">
                  💡 A funcionalidade de geração e download do PDF será implementada em breve
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default RelatorioEvolucao;
