
import React, { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import ChatSidebar from "@/components/chat/ChatSidebar";
import ChatArea from "@/components/chat/ChatArea";
import { ChatProvider } from "@/contexts/ChatContext";

const Chat = () => {
  const [selectedChat, setSelectedChat] = useState<string | null>(null);

  return (
    <ChatProvider>
      <AppLayout activePath="/chat">
        <div className="h-full flex bg-white">
          <ChatSidebar 
            selectedChat={selectedChat}
            onSelectChat={setSelectedChat}
          />
          <ChatArea selectedChat={selectedChat} />
        </div>
      </AppLayout>
    </ChatProvider>
  );
};

export default Chat;
