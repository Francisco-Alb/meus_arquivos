
import React, { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { StatusCard } from "@/components/invoices/StatusCard";
import { InvoiceTable } from "@/components/invoices/InvoiceTable";
import { useSupabaseInvoices } from "@/hooks/useSupabaseInvoices";
import { FileText, Clock, CheckCircle, XCircle, AlertTriangle, DollarSign, TrendingUp } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";
import { StatusType } from "@/components/invoices/StatusBadge";

type Invoice = Database["public"]["Tables"]["invoices"]["Row"];

interface ConvertedInvoice {
  id: string;
  requestNumber: string;
  creditor: string;
  invoiceNumber: string;
  competence: string;
  value: number;
  status: StatusType;
  species: string | null;
  observation: string | null;
  owner: string | null;
  createdAt: Date;
  updatedAt: Date;
}

interface IndexProps {
  searchQuery?: string;
}

const Index: React.FC<IndexProps> = ({ searchQuery = "" }) => {
  const { invoices, loading } = useSupabaseInvoices();
  const [activeFilter, setActiveFilter] = useState<string>("todos");

  // Converter dados do Supabase para o formato esperado pelo InvoiceTable
  const convertedInvoices: ConvertedInvoice[] = invoices.map(invoice => ({
    id: invoice.id,
    requestNumber: invoice.request_number,
    creditor: invoice.creditor_name,
    invoiceNumber: invoice.invoice_number,
    competence: invoice.competence,
    value: invoice.value,
    status: invoice.status as StatusType,
    species: invoice.species,
    observation: invoice.observation,
    owner: invoice.owner,
    createdAt: new Date(invoice.created_at),
    updatedAt: new Date(invoice.updated_at)
  }));

  const filteredInvoices = convertedInvoices.filter(invoice => {
    const matchesSearch = !searchQuery || 
      invoice.creditor.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.requestNumber.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = activeFilter === "todos" || invoice.status === activeFilter;
    
    return matchesSearch && matchesFilter;
  });

  const totalInvoices = invoices.length;
  const pendingCount = invoices.filter(inv => inv.status === "pendente").length;
  const inAnalysisCount = invoices.filter(inv => inv.status === "analise").length;
  const approvedCount = invoices.filter(inv => inv.status === "aprovada").length;
  const rejectedCount = invoices.filter(inv => inv.status === "nao-aprovada").length;
  const correctedCount = invoices.filter(inv => inv.status === "corrigida").length;
  const paidCount = invoices.filter(inv => inv.status === "paga").length;

  const totalValue = invoices.reduce((sum, inv) => sum + Number(inv.value || 0), 0);

  if (loading) {
    return (
      <AppLayout>
        <div className="p-8">
          <div className="animate-pulse">Carregando...</div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-8 p-8">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Visão geral das notas fiscais e prestação de contas
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div 
            className="flex items-center gap-3 p-4 rounded-lg cursor-pointer transition-all bg-blue-50 text-blue-700"
            onClick={() => setActiveFilter("todos")}
          >
            <div className="p-2 rounded-full bg-white">
              <FileText size={24} className="text-blue-700" />
            </div>
            <div>
              <p className="text-sm font-medium">Total de Notas</p>
              <p className="text-2xl font-bold">{totalInvoices}</p>
            </div>
          </div>

          <StatusCard
            type="pendente"
            count={pendingCount}
            active={activeFilter === "pendente"}
            onClick={() => setActiveFilter("pendente")}
          />
          
          <StatusCard
            type="analise"
            count={inAnalysisCount}
            active={activeFilter === "analise"}
            onClick={() => setActiveFilter("analise")}
          />
          
          <StatusCard
            type="aprovada"
            count={approvedCount}
            active={activeFilter === "aprovada"}
            onClick={() => setActiveFilter("aprovada")}
          />
          
          <StatusCard
            type="nao-aprovada"
            count={rejectedCount}
            active={activeFilter === "nao-aprovada"}
            onClick={() => setActiveFilter("nao-aprovada")}
          />
          
          <StatusCard
            type="corrigida"
            count={correctedCount}
            active={activeFilter === "corrigida"}
            onClick={() => setActiveFilter("corrigida")}
          />

          <div className="flex items-center gap-3 p-4 rounded-lg bg-green-50 text-green-700">
            <div className="p-2 rounded-full bg-white">
              <DollarSign size={24} className="text-green-700" />
            </div>
            <div>
              <p className="text-sm font-medium">Valor Total</p>
              <p className="text-2xl font-bold">
                {new Intl.NumberFormat('pt-BR', {
                  style: 'currency',
                  currency: 'BRL'
                }).format(totalValue)}
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-2xl font-semibold tracking-tight">Notas Fiscais</h2>
          <InvoiceTable 
            invoices={filteredInvoices}
          />
        </div>
      </div>
    </AppLayout>
  );
};

export default Index;
