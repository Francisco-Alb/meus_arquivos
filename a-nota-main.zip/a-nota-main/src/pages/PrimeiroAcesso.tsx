
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2, UserPlus, AlertCircle, CheckCircle } from 'lucide-react';

const PrimeiroAcesso = () => {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    password: '',
    confirmPassword: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [debugInfo, setDebugInfo] = useState<string[]>([]);
  const [success, setSuccess] = useState(false);
  const { signUp } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const addDebugInfo = (message: string) => {
    console.log('PrimeiroAcesso:', message);
    setDebugInfo(prev => [...prev, `${new Date().toLocaleTimeString()}: ${message}`]);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    addDebugInfo('Iniciando processo de cadastro');
    setDebugInfo([]); // Limpar logs anteriores
    setSuccess(false);
    
    // Validações
    if (formData.password !== formData.confirmPassword) {
      addDebugInfo('Erro: Senhas não coincidem');
      toast({
        title: "Erro",
        description: "As senhas não coincidem",
        variant: "destructive"
      });
      return;
    }

    if (formData.password.length < 6) {
      addDebugInfo('Erro: Senha muito curta');
      toast({
        title: "Erro",
        description: "A senha deve ter pelo menos 6 caracteres",
        variant: "destructive"
      });
      return;
    }

    if (!formData.nome || !formData.email) {
      addDebugInfo('Erro: Campos obrigatórios em branco');
      toast({
        title: "Erro",
        description: "Nome e email são obrigatórios",
        variant: "destructive"
      });
      return;
    }

    // Validar formato do email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      addDebugInfo('Erro: Email com formato inválido');
      toast({
        title: "Erro",
        description: "Por favor, insira um email válido",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    addDebugInfo('Validações passaram - iniciando cadastro');

    try {
      const userData = {
        nome: formData.nome.trim(),
        telefone: formData.telefone.trim() || null,
        cargo: 'gerente_prestacao_contas' as const
      };

      addDebugInfo(`Dados para cadastro: ${JSON.stringify(userData)}`);
      addDebugInfo(`Email: ${formData.email}`);

      const { error } = await signUp(formData.email.trim(), formData.password, userData);

      if (error) {
        addDebugInfo(`Erro retornado pelo signUp: ${error.message}`);
        console.error('PrimeiroAcesso: Erro completo:', error);
        
        let errorMessage = 'Erro no cadastro';
        
        if (error.message?.includes('User already registered')) {
          errorMessage = 'Este email já está cadastrado';
        } else if (error.message?.includes('Invalid email')) {
          errorMessage = 'Email inválido';
        } else if (error.message?.includes('Password')) {
          errorMessage = 'Senha inválida (mínimo 6 caracteres)';
        } else if (error.message?.includes('conexão') || error.message?.includes('connection')) {
          errorMessage = 'Erro de conexão com o banco de dados. Verifique sua internet.';
        } else {
          errorMessage = error.message || 'Erro desconhecido no cadastro';
        }

        toast({
          title: "Erro no cadastro",
          description: errorMessage,
          variant: "destructive"
        });
      } else {
        addDebugInfo('Cadastro realizado com sucesso!');
        addDebugInfo('O perfil será criado automaticamente pelo trigger do banco');
        setSuccess(true);
        
        toast({
          title: "Sucesso!",
          description: "Gerente cadastrado com sucesso! Redirecionando para o login...",
        });
        
        // Aguardar um pouco antes de redirecionar
        setTimeout(() => {
          navigate('/login');
        }, 3000);
      }
    } catch (error) {
      addDebugInfo(`Erro inesperado capturado: ${(error as Error).message}`);
      console.error('PrimeiroAcesso: Erro inesperado:', error);
      toast({
        title: "Erro inesperado",
        description: "Tente novamente. Se o problema persistir, verifique sua conexão.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1 text-center">
            <div className="flex justify-center mb-4">
              <CheckCircle className="h-16 w-16 text-green-500" />
            </div>
            <CardTitle className="text-2xl font-bold text-green-700">Cadastro Realizado!</CardTitle>
            <CardDescription>
              O gerente foi cadastrado com sucesso. Redirecionando para o login...
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="w-full max-w-4xl flex gap-6">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1 text-center">
            <CardTitle className="text-2xl font-bold">Primeiro Acesso</CardTitle>
            <CardDescription>
              Cadastre o primeiro Gerente de Prestação de Contas
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nome">Nome Completo *</Label>
                <Input
                  id="nome"
                  type="text"
                  placeholder="Digite o nome completo"
                  value={formData.nome}
                  onChange={(e) => handleInputChange('nome', e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Digite o email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="telefone">Telefone</Label>
                <Input
                  id="telefone"
                  type="tel"
                  placeholder="Digite o telefone (opcional)"
                  value={formData.telefone}
                  onChange={(e) => handleInputChange('telefone', e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password">Senha *</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Digite a senha (mín. 6 caracteres)"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  required
                  minLength={6}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirmar Senha *</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Confirme a senha"
                  value={formData.confirmPassword}
                  onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                  required
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Cadastrando...
                  </>
                ) : (
                  <>
                    <UserPlus className="mr-2 h-4 w-4" />
                    Cadastrar Gerente
                  </>
                )}
              </Button>
            </form>
            
            <div className="text-center">
              <Button 
                variant="ghost" 
                onClick={() => navigate('/login')}
                className="w-full"
                disabled={isLoading}
              >
                Voltar ao Login
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Painel de Debug */}
        {debugInfo.length > 0 && (
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                Log de Depuração
              </CardTitle>
              <CardDescription>
                Informações técnicas do processo de cadastro
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 p-3 rounded-md max-h-80 overflow-y-auto">
                {debugInfo.map((info, index) => (
                  <div key={index} className="text-xs mb-1 font-mono">
                    {info}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default PrimeiroAcesso;
