
import React, { useState } from 'react';
import AppLayout from '@/components/layout/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useSupabaseInvoices } from '@/hooks/useSupabaseInvoices';
import { useSupabaseCredores } from '@/hooks/useSupabaseCredores';
import { Loader2, Plus } from 'lucide-react';

const CadastroNotas = () => {
  const [formData, setFormData] = useState({
    numeroSolicitacao: '',
    credorId: '',
    numeroNota: '',
    competencia: '',
    valor: '',
    observacao: '',
    especie: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  
  const { addInvoice, projects } = useSupabaseInvoices();
  const { credores } = useSupabaseCredores();
  const { toast } = useToast();

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const selectedCredor = credores.find(c => c.id === formData.credorId);
      
      if (!selectedCredor) {
        toast({
          title: "Erro",
          description: "Selecione um credor válido",
          variant: "destructive"
        });
        return;
      }

      const invoiceData = {
        request_number: formData.numeroSolicitacao,
        creditor_id: formData.credorId,
        creditor_name: selectedCredor.nome,
        creditor_cnpj: selectedCredor.cnpj,
        invoice_number: formData.numeroNota,
        competence: formData.competencia,
        value: parseFloat(formData.valor),
        status: 'pendente' as const,
        observation: formData.observacao || '',
        species: formData.especie as any,
        owner: 'Sistema',
        project_id: projects?.[0]?.id || '00000000-0000-0000-0000-000000000000'
      };

      await addInvoice(invoiceData);

      toast({
        title: "Sucesso",
        description: "Nota fiscal cadastrada com sucesso!"
      });

      // Reset form
      setFormData({
        numeroSolicitacao: '',
        credorId: '',
        numeroNota: '',
        competencia: '',
        valor: '',
        observacao: '',
        especie: ''
      });

    } catch (error) {
      console.error('Erro ao cadastrar nota:', error);
      toast({
        title: "Erro",
        description: "Erro ao cadastrar nota fiscal",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AppLayout activePath="/cadastro-notas">
      <div className="space-y-6 p-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Cadastro de Notas Fiscais</h1>
          <p className="text-muted-foreground">
            Cadastre novas notas fiscais para prestação de contas
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Nova Nota Fiscal</CardTitle>
            <CardDescription>
              Preencha os dados da nota fiscal para cadastro no sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="numeroSolicitacao">Número da Solicitação</Label>
                  <Input
                    id="numeroSolicitacao"
                    placeholder="Digite o número da solicitação"
                    value={formData.numeroSolicitacao}
                    onChange={(e) => handleInputChange('numeroSolicitacao', e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="credorId">Credor</Label>
                  <Select value={formData.credorId} onValueChange={(value) => handleInputChange('credorId', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o credor" />
                    </SelectTrigger>
                    <SelectContent>
                      {credores.map((credor) => (
                        <SelectItem key={credor.id} value={credor.id}>
                          {credor.nome} - {credor.cnpj}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="numeroNota">Número da Nota Fiscal</Label>
                  <Input
                    id="numeroNota"
                    placeholder="Digite o número da nota fiscal"
                    value={formData.numeroNota}
                    onChange={(e) => handleInputChange('numeroNota', e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="competencia">Competência</Label>
                  <Input
                    id="competencia"
                    type="month"
                    value={formData.competencia}
                    onChange={(e) => handleInputChange('competencia', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="valor">Valor (R$)</Label>
                  <Input
                    id="valor"
                    type="number"
                    step="0.01"
                    placeholder="0,00"
                    value={formData.valor}
                    onChange={(e) => handleInputChange('valor', e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="especie">Espécie</Label>
                  <Select value={formData.especie} onValueChange={(value) => handleInputChange('especie', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a espécie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="NCI">NCI - Nota de Crédito Interno</SelectItem>
                      <SelectItem value="ND">ND - Nota de Débito</SelectItem>
                      <SelectItem value="MAT_MED">MAT_MED - Material Médico</SelectItem>
                      <SelectItem value="NRT">NRT - Nota de Reembolso de Taxa</SelectItem>
                      <SelectItem value="NST">NST - Nota de Serviço de Terceiros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacao">Observação</Label>
                <Textarea
                  id="observacao"
                  placeholder="Digite observações sobre a nota fiscal (opcional)"
                  value={formData.observacao}
                  onChange={(e) => handleInputChange('observacao', e.target.value)}
                  rows={3}
                />
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Cadastrando...
                  </>
                ) : (
                  <>
                    <Plus className="mr-2 h-4 w-4" />
                    Cadastrar Nota Fiscal
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default CadastroNotas;
