
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';

const SUPABASE_URL = "https://zfmpbcadnbkbiooclksz.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpmbXBiY2FkbmJrYmlvb2Nsa3N6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg0ODUxODQsImV4cCI6MjA2NDA2MTE4NH0.BXVhQmsNW6CVKjo2pg7Kf4Z2-3000Hgg85iaX7I18vc";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
});
