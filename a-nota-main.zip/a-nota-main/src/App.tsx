
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { NotificationsProvider } from "@/contexts/NotificationsContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Login from "./pages/Login";
import PrimeiroAcesso from "./pages/PrimeiroAcesso";
import Index from "./pages/Index";
import CadastroCredores from "./pages/CadastroCredores";
import CadastroNotas from "./pages/CadastroNotas";
import Justificativas from "./pages/Justificativas";
import Certidoes from "./pages/Certidoes";
import RelatorioEvolucao from "./pages/RelatorioEvolucao";
import Perfil from "./pages/Perfil";
import Chat from "./pages/Chat";
import Avisos from "./pages/Avisos";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <NotificationsProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/primeiro-acesso" element={<PrimeiroAcesso />} />
              <Route path="/" element={
                <ProtectedRoute>
                  <Index />
                </ProtectedRoute>
              } />
              <Route path="/cadastro-credores" element={
                <ProtectedRoute>
                  <CadastroCredores />
                </ProtectedRoute>
              } />
              <Route path="/cadastro-notas" element={
                <ProtectedRoute>
                  <CadastroNotas />
                </ProtectedRoute>
              } />
              <Route path="/justificativas" element={
                <ProtectedRoute>
                  <Justificativas />
                </ProtectedRoute>
              } />
              <Route path="/certidoes" element={
                <ProtectedRoute>
                  <Certidoes />
                </ProtectedRoute>
              } />
              <Route path="/perfil" element={
                <ProtectedRoute>
                  <Perfil />
                </ProtectedRoute>
              } />
              <Route path="/chat" element={
                <ProtectedRoute>
                  <Chat />
                </ProtectedRoute>
              } />
              <Route path="/avisos" element={
                <ProtectedRoute>
                  <Avisos />
                </ProtectedRoute>
              } />
              <Route path="/exportar" element={
                <ProtectedRoute>
                  <RelatorioEvolucao />
                </ProtectedRoute>
              } />
              <Route path="/sair" element={<NotFound />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </NotificationsProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
