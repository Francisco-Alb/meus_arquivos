
import { PDFDocument, rgb } from 'pdf-lib';

export interface CertificateFile {
  type: string;
  filePath: string | null;
  date: string | null;
}

export const joinCertificatesPDF = async (
  creditorName: string,
  certificates: CertificateFile[],
  downloadFile: (filePath: string) => Promise<Blob | null>
): Promise<Blob> => {
  console.log('Starting PDF join process for:', creditorName);
  console.log('Certificates to process:', certificates);
  
  // Create new PDF document
  const pdfDoc = await PDFDocument.create();
  
  // Add cover page
  const coverPage = pdfDoc.addPage([595.28, 841.89]); // A4 size
  const fontSize = 14;
  const titleFontSize = 18;
  
  // Main title
  coverPage.drawText('CERTIDÕES NEGATIVAS DE DÉBITOS', {
    x: 50,
    y: 750,
    size: titleFontSize,
    color: rgb(0, 0, 0),
  });
  
  // Creditor name
  coverPage.drawText(`Credor: ${creditorName}`, {
    x: 50,
    y: 710,
    size: fontSize,
    color: rgb(0, 0, 0),
  });
  
  // Generation date
  coverPage.drawText(`Gerado em: ${new Date().toLocaleDateString('pt-BR')}`, {
    x: 50,
    y: 680,
    size: fontSize,
    color: rgb(0, 0, 0),
  });
  
  // List of certificates
  let yPosition = 640;
  coverPage.drawText('Certidões incluídas:', {
    x: 50,
    y: yPosition,
    size: fontSize,
    color: rgb(0, 0, 0),
  });
  
  // Process each certificate
  const availableCertificates = certificates.filter(cert => cert.filePath);
  console.log('Available certificates for joining:', availableCertificates.length);
  
  for (const cert of certificates) {
    yPosition -= 25;
    const status = cert.filePath ? 'Incluída' : 'Não disponível';
    const dateText = cert.date ? ` - Válida até: ${new Date(cert.date).toLocaleDateString('pt-BR')}` : '';
    
    coverPage.drawText(`• ${cert.type.toUpperCase()}: ${status}${dateText}`, {
      x: 70,
      y: yPosition,
      size: fontSize - 2,
      color: cert.filePath ? rgb(0, 0.5, 0) : rgb(0.8, 0, 0),
    });

    // If file exists, download and add to PDF
    if (cert.filePath) {
      try {
        console.log(`Processing ${cert.type} certificate...`);
        
        const fileBlob = await downloadFile(cert.filePath);
        if (fileBlob && fileBlob.size > 0) {
          console.log(`Downloaded ${cert.type} certificate, size: ${fileBlob.size} bytes`);
          
          const arrayBuffer = await fileBlob.arrayBuffer();
          const pdfToMerge = await PDFDocument.load(arrayBuffer);
          const pages = await pdfDoc.copyPages(pdfToMerge, pdfToMerge.getPageIndices());
          
          pages.forEach((page) => pdfDoc.addPage(page));
          console.log(`Added ${pages.length} pages from ${cert.type} certificate`);
        } else {
          console.warn(`Failed to download or empty file for ${cert.type}`);
        }
      } catch (error) {
        console.error(`Error processing ${cert.type} certificate:`, error);
      }
    }
  }
  
  // Add footer note if some certificates are missing
  if (availableCertificates.length < certificates.length) {
    yPosition -= 40;
    coverPage.drawText('Nota: Algumas certidões não estavam disponíveis no momento da geração.', {
      x: 50,
      y: yPosition,
      size: fontSize - 3,
      color: rgb(0.5, 0.5, 0.5),
    });
  }
  
  console.log('Finalizing PDF document...');
  
  // Serialize PDF
  const pdfBytes = await pdfDoc.save();
  
  console.log(`Generated PDF with ${pdfDoc.getPageCount()} total pages`);
  
  // Return as Blob
  return new Blob([pdfBytes], { type: 'application/pdf' });
};

export const downloadPDF = (blob: Blob, filename: string) => {
  console.log('Initiating PDF download:', filename);
  
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.style.display = 'none';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  // Clean up the URL object
  setTimeout(() => URL.revokeObjectURL(url), 100);
  
  console.log('PDF download initiated successfully');
};
