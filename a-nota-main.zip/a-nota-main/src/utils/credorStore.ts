
import { useState, useEffect } from "react";

// Interface for the Credor type
export interface Credor {
  id: number;
  nome: string;
  cnpj: string;
}

// Mock initial credores
export const initialCredores: Credor[] = [
  { id: 1, nome: "Fornecedor ABC Ltda", cnpj: "01.234.432/0001-98" },
  { id: 2, nome: "Serviços XYZ S.A.", cnpj: "98.765.432/0001-01" },
  { id: 3, nome: "Distribuidora Fast Ltda", cnpj: "45.678.123/0001-45" },
  { id: 4, nome: "Tech Solutions ME", cnpj: "12.345.678/0001-90" },
  { id: 5, nome: "Consultoria Omega S.A.", cnpj: "76.543.210/0001-87" },
];

// Interface for document info
export interface DocumentInfo {
  date: string | null;
  status: string;
  filePath?: string | null;
}

// Interface for certificate
export interface Certificate {
  id: number;
  credor: string;
  cnpj: string;
  municipal: DocumentInfo;
  estadual: DocumentInfo;
  federal: DocumentInfo;
  trabalhista: DocumentInfo;
  fgts: DocumentInfo;
}

// Get creditors from localStorage
const getStoredCredores = (): Credor[] => {
  const stored = localStorage.getItem('globalCredores');
  return stored ? JSON.parse(stored) : initialCredores;
};

// Set creditors to localStorage
export const setStoredCredores = (credores: Credor[]) => {
  localStorage.setItem('globalCredores', JSON.stringify(credores));
};

// Get certificates from localStorage
export const getStoredCertificates = (): Certificate[] => {
  const stored = localStorage.getItem('globalCertificates');
  if (stored) return JSON.parse(stored);
  
  // If no certificates in storage, generate initial ones based on credores
  const credores = getStoredCredores();
  const initialCertificates = credores.map(credor => createCertificateFromCredor(credor));
  return initialCertificates;
};

// Set certificates to localStorage
export const setStoredCertificates = (certificates: Certificate[]) => {
  localStorage.setItem('globalCertificates', JSON.stringify(certificates));
};

// Create a certificate from a creditor
export const createCertificateFromCredor = (credor: Credor): Certificate => {
  return {
    id: credor.id,
    credor: credor.nome,
    cnpj: credor.cnpj,
    municipal: { date: null, status: "AUSENTE" },
    estadual: { date: null, status: "AUSENTE" },
    federal: { date: null, status: "AUSENTE" },
    trabalhista: { date: null, status: "AUSENTE" },
    fgts: { date: null, status: "AUSENTE" }
  };
};

// Custom hook to manage credores state
export const useCredores = () => {
  const [credores, setCredores] = useState<Credor[]>(getStoredCredores());

  // Update localStorage whenever credores changes
  useEffect(() => {
    setStoredCredores(credores);
  }, [credores]);

  // Add a new credor and update certificates
  const addCredor = (newCredor: Credor) => {
    setCredores(prev => [...prev, newCredor]);
    
    // Create a new certificate for the credor
    const certificates = getStoredCertificates();
    const newCertificate = createCertificateFromCredor(newCredor);
    setStoredCertificates([...certificates, newCertificate]);
  };
  
  // Edit an existing credor
  const editCredor = (updatedCredor: Credor) => {
    setCredores(prev => prev.map(credor => 
      credor.id === updatedCredor.id ? updatedCredor : credor
    ));
    
    // Update the certificate for this credor
    const certificates = getStoredCertificates();
    const updatedCertificates = certificates.map(cert => 
      cert.id === updatedCredor.id 
        ? { ...cert, credor: updatedCredor.nome, cnpj: updatedCredor.cnpj }
        : cert
    );
    setStoredCertificates(updatedCertificates);
  };
  
  // Delete a credor
  const deleteCredor = (id: number) => {
    setCredores(prev => prev.filter(credor => credor.id !== id));
    
    // Remove the certificate for this credor
    const certificates = getStoredCertificates();
    const updatedCertificates = certificates.filter(cert => cert.id !== id);
    setStoredCertificates(updatedCertificates);
  };

  return {
    credores,
    setCredores,
    addCredor,
    editCredor,
    deleteCredor
  };
};

// Custom hook to manage certificates state
export const useCertificates = () => {
  const [certificates, setCertificates] = useState<Certificate[]>(getStoredCertificates());

  // Update localStorage whenever certificates changes
  useEffect(() => {
    setStoredCertificates(certificates);
  }, [certificates]);

  return {
    certificates,
    setCertificates
  };
};
